// Icons + shared atoms for Whales Social
// All exported to window for cross-file access

const Icon = ({ name, size = 22, stroke = 2, ...rest }) => {
  const s = { width: size, height: size, ...rest.style };
  const p = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round', ...rest, style: s };
  switch (name) {
    case 'menu': return <svg {...p}><line x1="4" y1="7" x2="20" y2="7" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="17" x2="14" y2="17" /></svg>;
    case 'search': return <svg {...p}><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.5" y2="16.5" /></svg>;
    case 'home': return <svg {...p}><path d="M3 11.5L12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z" /></svg>;
    case 'home-fill': return <svg {...{ ...p, fill: 'currentColor', stroke: 'currentColor' }}><path d="M3 11.5L12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z" /></svg>;
    case 'sparkles': return <svg {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8" /></svg>;
    case 'compass': return <svg {...p}><circle cx="12" cy="12" r="9" /><path d="M15.5 8.5l-2 5-5 2 2-5z" /></svg>;
    case 'bell': return <svg {...p}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9zM10.5 21a1.5 1.5 0 0 0 3 0" /></svg>;
    case 'mail': return <svg {...p}><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 7l9 6 9-6" /></svg>;
    case 'wallet': return <svg {...p}><path d="M3 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2H5a2 2 0 0 0 0 4h16v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><circle cx="17" cy="13" r="1.2" fill="currentColor" stroke="none"/></svg>;
    case 'live': return <svg {...p}><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none" /><path d="M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14M8 8a6 6 0 0 0 0 8M16 8a6 6 0 0 1 0 8" /></svg>;
    case 'bookmark': return <svg {...p}><path d="M6 3h12v18l-6-4-6 4z" /></svg>;
    case 'bookmark-fill': return <svg {...{ ...p, fill: 'currentColor' }}><path d="M6 3h12v18l-6-4-6 4z" /></svg>;
    case 'settings': return <svg {...p}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1A1.7 1.7 0 0 0 15 4.6a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" /></svg>;
    case 'heart': return <svg {...p}><path d="M12 21s-7-4.35-7-11a4 4 0 0 1 7-2.65A4 4 0 0 1 19 10c0 6.65-7 11-7 11z" /></svg>;
    case 'heart-fill': return <svg {...{ ...p, fill: 'currentColor', stroke: 'currentColor' }}><path d="M12 21s-7-4.35-7-11a4 4 0 0 1 7-2.65A4 4 0 0 1 19 10c0 6.65-7 11-7 11z" /></svg>;
    case 'reply': return <svg {...p}><path d="M21 15a4 4 0 0 1-4 4H8l-5 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" /></svg>;
    case 'repost': return <svg {...p}><polyline points="17 1 21 5 17 9" /><path d="M3 11V9a4 4 0 0 1 4-4h14" /><polyline points="7 23 3 19 7 15" /><path d="M21 13v2a4 4 0 0 1-4 4H3" /></svg>;
    case 'share': return <svg {...p}><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" /><polyline points="16 6 12 2 8 6" /><line x1="12" y1="2" x2="12" y2="15" /></svg>;
    case 'tip': return <svg {...p}><circle cx="12" cy="12" r="9" /><path d="M12 7v10M9 9.5c0-1 1-2 3-2s3 1 3 2-1 1.5-3 2-3 1-3 2 1 2 3 2 3-1 3-2" /></svg>;
    case 'eye': return <svg {...p}><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></svg>;
    case 'more': return <svg {...p}><circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none" /><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" /><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none" /></svg>;
    case 'close': return <svg {...p}><line x1="6" y1="6" x2="18" y2="18" /><line x1="18" y1="6" x2="6" y2="18" /></svg>;
    case 'arrow-left': return <svg {...p}><line x1="20" y1="12" x2="4" y2="12" /><polyline points="10 18 4 12 10 6" /></svg>;
    case 'arrow-right': return <svg {...p}><line x1="4" y1="12" x2="20" y2="12" /><polyline points="14 6 20 12 14 18" /></svg>;
    case 'arrow-up-right': return <svg {...p}><line x1="7" y1="17" x2="17" y2="7" /><polyline points="7 7 17 7 17 17" /></svg>;
    case 'arrow-down-right': return <svg {...p}><line x1="7" y1="7" x2="17" y2="17" /><polyline points="17 7 17 17 7 17" /></svg>;
    case 'plus': return <svg {...p}><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>;
    case 'minus': return <svg {...p}><line x1="5" y1="12" x2="19" y2="12" /></svg>;
    case 'check': return <svg {...p}><polyline points="5 12 10 17 19 7" /></svg>;
    case 'flame': return <svg {...p}><path d="M12 2s4 4 4 8a4 4 0 1 1-8 0c0-1.5.5-2.5 1-3.5C9 8 8 9 8 11a6 6 0 1 0 12 0c0-5-4-8-8-9z" /></svg>;
    case 'image': return <svg {...p}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="9" cy="9" r="2" /><path d="M21 16l-5-5-9 9" /></svg>;
    case 'gif': return <svg {...p}><rect x="3" y="6" width="18" height="12" rx="2" /><path d="M9 10v4M9 10H7v4h2M14 10v4M19 10h-2v4M19 12h-2" /></svg>;
    case 'mic': return <svg {...p}><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></svg>;
    case 'video': return <svg {...p}><rect x="2" y="6" width="14" height="12" rx="2" /><polygon points="22 8 16 12 22 16 22 8" /></svg>;
    case 'send': return <svg {...p}><line x1="22" y1="2" x2="11" y2="13" /><polygon points="22 2 15 22 11 13 2 9 22 2" /></svg>;
    case 'globe': return <svg {...p}><circle cx="12" cy="12" r="9" /><line x1="3" y1="12" x2="21" y2="12" /><path d="M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></svg>;
    case 'verified': return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M12 1l2.6 2.1 3.3-.4 1.4 3 3 1.4-.4 3.3L24 13l-2.1 2.6.4 3.3-3 1.4-1.4 3-3.3-.4L12 25l-2.6-2.1-3.3.4-1.4-3-3-1.4.4-3.3L0 13l2.1-2.6-.4-3.3 3-1.4 1.4-3 3.3.4z" /><polyline points="8 13 11 16 17 9" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>;
    case 'whale': return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor"><path d="M3 14c0-3 2-5 5-5h6c4 0 7 2 7 5 0 1 0 2-1 3l1 2-3-1c-1 1-3 1-4 1H8c-3 0-5-2-5-5z" /><circle cx="9" cy="13" r="0.8" fill="white" /><path d="M14 9c0-2 1-4 2-4M16 5c0 2 1 3 2 4" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" /></svg>;
    case 'fire': return <svg {...p}><path d="M8 14s-1-3 0-6c1-3 4-5 4-5s0 3 2 5 3 4 3 7a5 5 0 1 1-10 0c0-2 1-3 1-3z" /></svg>;
    case 'trend-up': return <svg {...p}><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>;
    case 'trend-down': return <svg {...p}><polyline points="3 7 9 13 13 9 21 17" /><polyline points="14 17 21 17 21 10" /></svg>;
    case 'shield': return <svg {...p}><path d="M12 2l8 4v6c0 5-4 9-8 10-4-1-8-5-8-10V6z" /></svg>;
    case 'lock': return <svg {...p}><rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" /></svg>;
    case 'logout': return <svg {...p}><path d="M16 17l5-5-5-5M21 12H9M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /></svg>;
    case 'qr': return <svg {...p}><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /><path d="M14 14h3v3h-3zM21 14v3M14 21h3M21 21h-3" /></svg>;
    case 'swap': return <svg {...p}><polyline points="17 1 21 5 17 9" /><path d="M3 5h18" /><polyline points="7 23 3 19 7 15" /><path d="M21 19H3" /></svg>;
    case 'card': return <svg {...p}><rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" /></svg>;
    case 'chart': return <svg {...p}><polyline points="3 3 3 21 21 21" /><polyline points="7 17 11 12 14 14 20 7" /></svg>;
    case 'cam': return <svg {...p}><path d="M3 7a2 2 0 0 1 2-2h3l2-2h4l2 2h3a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><circle cx="12" cy="13" r="4" /></svg>;
    case 'flip': return <svg {...p}><path d="M21 12a9 9 0 1 1-3.3-7" /><polyline points="21 4 21 9 16 9" /></svg>;
    case 'users': return <svg {...p}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 16 11" /></svg>;
    case 'pin': return <svg {...p}><line x1="12" y1="17" x2="12" y2="22" /><path d="M5 17h14l-2-4V5h1V3H6v2h1v8z" /></svg>;
    case 'language': return <svg {...p}><path d="M5 8h11M9 4v4M9 12c0 4-2 6-4 8M11 16c-2-2-4-4-4-8M14 21l5-12 5 12M16 17h6" /></svg>;
    case 'moon': return <svg {...p}><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" /></svg>;
    case 'help': return <svg {...p}><circle cx="12" cy="12" r="9" /><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.5-2.5 2-2.5 4M12 17h.01" /></svg>;
    case 'palette': return <svg {...p}><path d="M12 3a9 9 0 0 0 0 18c1 0 2-1 2-2s-1-2-1-3 1-2 2-2h2a4 4 0 0 0 4-4 9 9 0 0 0-9-7z" /><circle cx="7.5" cy="10.5" r="1" fill="currentColor" /><circle cx="12" cy="7.5" r="1" fill="currentColor" /><circle cx="16.5" cy="10.5" r="1" fill="currentColor" /></svg>;
    case 'edit': return <svg {...p}><path d="M11 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-6" /><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z" /></svg>;
    case 'feather': return <svg {...p}><path d="M20 13c0 5-3 8-8 8H4l8-8M14 5l5 5M16 8l-7 7-2 4 4-2 7-7M14 5h-3l-7 7v3" /></svg>;
    case 'calendar': return <svg {...p}><rect x="3" y="5" width="18" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="3" y1="11" x2="21" y2="11" /></svg>;
    case 'mappin': return <svg {...p}><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>;
    case 'link': return <svg {...p}><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1" /><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1" /></svg>;
    default: return null;
  }
};

const Avatar = ({ user, size = 40, showWhale = false }) => {
  const u = window.WhalesData.users[user] || { name: user, avatar: { hue: 200, seed: '?' } };
  const hue = u.avatar?.hue ?? 200;
  const seed = u.avatar?.seed || (u.name?.[0] || '?');
  return (
    <div className="avatar" style={{
      width: size, height: size, fontSize: size * 0.36,
      background: `linear-gradient(135deg, oklch(0.55 0.15 ${hue}) 0%, oklch(0.35 0.12 ${hue + 30}) 100%)`,
      color: 'white',
    }}>
      {seed}
      {showWhale && u.whale && (
        <div style={{
          position: 'absolute', bottom: -2, right: -2,
          width: size * 0.42, height: size * 0.42,
          background: 'var(--whale-gold)',
          borderRadius: '50%',
          display: 'grid', placeItems: 'center',
          boxShadow: '0 0 0 2px var(--bg)',
          color: '#1a0e00',
        }}>
          <Icon name="whale" size={size * 0.28} />
        </div>
      )}
    </div>
  );
};

const UserName = ({ user, withTime, time, compact }) => {
  const u = window.WhalesData.users[user] || { name: user, handle: user };
  return (
    <div className="row" style={{ gap: 4, minWidth: 0, flexWrap: 'nowrap' }}>
      <span style={{ fontWeight: 700, fontSize: 14, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{u.name}</span>
      {u.verified && <span className="badge-verified" style={{ color: 'var(--whale-blue)' }}><Icon name="verified" size={14} /></span>}
      {u.whale && <span className="badge-whale"><Icon name="whale" size={14} /></span>}
      {!compact && <span style={{ fontSize: 14, color: 'var(--text-3)', whiteSpace: 'nowrap' }}>@{u.handle}</span>}
      {withTime && <span style={{ fontSize: 14, color: 'var(--text-3)' }}>· {time}</span>}
    </div>
  );
};

const StatusBar = () => (
  <div className="status-bar">
    <span>9:41</span>
    <div className="right">
      {/* signal */}
      <svg width="18" height="12" viewBox="0 0 18 12" fill="currentColor"><rect x="0" y="8" width="3" height="4" rx="0.5" /><rect x="5" y="5" width="3" height="7" rx="0.5" /><rect x="10" y="2" width="3" height="10" rx="0.5" /><rect x="15" y="0" width="3" height="12" rx="0.5" /></svg>
      {/* wifi */}
      <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor"><path d="M8 12a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm0-5a4 4 0 0 1 2.83 1.17l1.41-1.41a6 6 0 0 0-8.48 0l1.41 1.41A4 4 0 0 1 8 7zm0-4a8 8 0 0 1 5.66 2.34l1.41-1.41a10 10 0 0 0-14.14 0l1.41 1.41A8 8 0 0 1 8 3z" /></svg>
      {/* battery */}
      <svg width="26" height="12" viewBox="0 0 26 12" fill="none"><rect x="0.5" y="0.5" width="22" height="11" rx="2.5" stroke="currentColor" opacity="0.5" /><rect x="2" y="2" width="19" height="8" rx="1.5" fill="currentColor" /><rect x="23.5" y="4" width="2" height="4" rx="1" fill="currentColor" opacity="0.5" /></svg>
    </div>
  </div>
);

// Whale logo
const WhaleLogo = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <defs>
      <linearGradient id="wg" x1="0" y1="0" x2="32" y2="32">
        <stop offset="0" stopColor="#00D68F" />
        <stop offset="1" stopColor="#00A86F" />
      </linearGradient>
    </defs>
    <path d="M3 18c0-4 3-7 7-7h8c5 0 9 3 9 7 0 1.5-.5 3-1.5 4l1.5 3-4-1.5c-1.5 1-3.5 1.5-5 1.5h-8c-4 0-7-3-7-7z" fill="url(#wg)" />
    <circle cx="11" cy="16" r="1.2" fill="#0A0E0C" />
    <path d="M19 11c0-3 1.5-5 3-5M22 6c0 2 1 4 3 5" stroke="#00D68F" strokeWidth="1.8" strokeLinecap="round" fill="none" />
  </svg>
);

// Number formatter
const fmt = (n) => {
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
  return String(n);
};

// Mini sparkline
const Sparkline = ({ dir = 'up', width = 60, height = 24 }) => {
  const points = dir === 'up'
    ? '0,20 8,18 16,15 24,16 32,12 40,8 48,9 56,4 60,3'
    : dir === 'down'
      ? '0,4 8,5 16,8 24,7 32,12 40,16 48,15 56,20 60,21'
      : '0,12 60,12';
  const color = dir === 'up' ? 'var(--whale-green)' : dir === 'down' ? 'var(--whale-red)' : 'var(--text-3)';
  return (
    <svg width={width} height={height} viewBox={`0 0 60 24`} fill="none">
      <polyline points={points} stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

Object.assign(window, { Icon, Avatar, UserName, StatusBar, WhaleLogo, fmt, Sparkline });
