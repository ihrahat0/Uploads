// Whales Social — wallet, live, settings, profile, post-detail, compose

const WalletScreen = ({ openMenu, go }) => {
  const holdings = [
    { tk: "ETH", name: "Ethereum", amt: "5.842", usd: 20281.45, change: "+2.4%", up: true, color: "#627EEA" },
    { tk: "BTC", name: "Bitcoin", amt: "0.0612", usd: 4151.81, change: "+0.8%", up: true, color: "#F7931A" },
    { tk: "SOL", name: "Solana", amt: "12.40", usd: 1782.40, change: "-1.2%", up: false, color: "#9945FF" },
    { tk: "USDC", name: "USD Coin", amt: "1,240.00", usd: 1240.00, change: "0.0%", up: true, color: "#2775CA" },
  ];
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <PageHeader onBack={() => go("discover")} title="Wallet" right={<button className="icon-btn"><IconQr size={20}/></button>}/>
      <div className="feed">
        {/* Balance hero */}
        <div style={{ margin: "16px 16px 8px", padding: "20px 18px", borderRadius: 24, position: "relative", overflow: "hidden",
          background: "radial-gradient(80% 100% at 0% 0%, rgba(0,224,138,.18), transparent 50%), radial-gradient(80% 100% at 100% 100%, rgba(245,194,73,.14), transparent 50%), linear-gradient(180deg, var(--bg-elev), var(--bg-elev-2))",
          border: "1px solid var(--line)",
        }}>
          <div style={{ fontSize: 12, color: "var(--text-3)", letterSpacing: ".05em", textTransform: "uppercase", fontWeight: 700 }}>Total balance</div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: 38, fontWeight: 700, letterSpacing: "-0.02em", marginTop: 4, lineHeight: 1.1 }}>
            $24,855<span style={{ color: "var(--text-3)", fontSize: 22 }}>.66</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 8px", borderRadius: 999, background: "rgba(0,224,138,.12)", color: "var(--whale-green)", fontSize: 12, fontWeight: 700 }}>↑ +$482.20</span>
            <span style={{ fontSize: 12.5, color: "var(--text-3)" }}>+1.98% today</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, marginTop: 18 }}>
            {[
              { label: "Send", I: IconShare },
              { label: "Receive", I: IconQr },
              { label: "Swap", I: IconRepost },
              { label: "Tip", I: IconHeart },
            ].map((b, i) => {
              const I = b.I;
              return (
                <button key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, padding: "10px 4px", borderRadius: 14, background: "rgba(255,255,255,.04)", border: "1px solid var(--line-soft)" }}>
                  <I size={18}/>
                  <span style={{ fontSize: 11.5, fontWeight: 600 }}>{b.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Wallet address chip */}
        <div style={{ margin: "8px 16px 16px", display: "flex", alignItems: "center", gap: 8, padding: "10px 14px", background: "var(--bg-elev)", border: "1px solid var(--line)", borderRadius: 14 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--whale-green)", boxShadow: "0 0 8px var(--whale-green)" }}/>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 12.5, color: "var(--text-2)" }}>0x7a3f...e21c</span>
          <span style={{ marginLeft: "auto", display: "flex", gap: 4, color: "var(--text-3)" }}>
            <button className="icon-btn" style={{ width: 28, height: 28 }}><IconCopy size={14}/></button>
            <button className="icon-btn" style={{ width: 28, height: 28 }}><IconQr size={14}/></button>
          </span>
        </div>

        <div style={{ padding: "8px 16px 8px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 16, fontWeight: 700, fontFamily: "var(--font-display)" }}>Holdings</span>
          <span style={{ fontSize: 12, color: "var(--text-3)" }}>4 assets</span>
        </div>
        {holdings.map(h => (
          <div key={h.tk} style={{ padding: "12px 16px", borderBottom: "1px solid var(--line-soft)", display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 38, height: 38, borderRadius: "50%", background: h.color, color: "#fff", display: "grid", placeItems: "center", fontFamily: "var(--font-mono)", fontWeight: 700, fontSize: 11 }}>{h.tk}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14.5, fontWeight: 700 }}>{h.name}</div>
              <div style={{ fontSize: 12, color: "var(--text-3)", fontFamily: "var(--font-mono)" }}>{h.amt} {h.tk}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 14.5, fontWeight: 700, fontFamily: "var(--font-mono)" }}>${h.usd.toLocaleString()}</div>
              <div style={{ fontSize: 12, color: h.up ? "var(--whale-green)" : "var(--like)", fontWeight: 600 }}>{h.change}</div>
            </div>
          </div>
        ))}
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const GoLiveScreen = ({ go }) => {
  const [title, setTitle] = React.useState("");
  const [audio, setAudio] = React.useState(true);
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%", background: "#000" }}>
      {/* Camera preview area */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden", background:
        "radial-gradient(70% 50% at 50% 30%, rgba(0,224,138,.15), transparent 60%), radial-gradient(60% 60% at 80% 90%, rgba(245,194,73,.1), transparent 60%), linear-gradient(180deg, #0E1218, #050709)"
      }}>
        {/* simulated viewfinder grid */}
        <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(255,255,255,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.04) 1px, transparent 1px)", backgroundSize: "40px 40px" }}/>

        {/* Top bar */}
        <div style={{ position: "absolute", top: 12, left: 12, right: 12, display: "flex", alignItems: "center", gap: 8, zIndex: 2 }}>
          <button className="icon-btn" onClick={() => go("discover")} style={{ background: "rgba(0,0,0,.4)", color: "#fff" }}><IconArrowLeft size={20}/></button>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", borderRadius: 999, background: "rgba(255,92,122,.18)", border: "1px solid rgba(255,92,122,.5)", fontSize: 11.5, fontWeight: 800, letterSpacing: ".08em", color: "#FF8FA3" }}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: "#FF5C7A", boxShadow: "0 0 8px #FF5C7A" }}/>
            LIVE
          </span>
          <span style={{ marginLeft: "auto", padding: "5px 10px", borderRadius: 999, background: "rgba(0,0,0,.4)", fontSize: 12, color: "#fff" }}>00:00</span>
          <span style={{ padding: "5px 10px", borderRadius: 999, background: "rgba(0,0,0,.4)", fontSize: 12, color: "#fff", display:"flex", alignItems:"center", gap: 4 }}>
            <IconUser size={12}/> 0
          </span>
        </div>

        {/* Center hint */}
        <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", color: "rgba(255,255,255,.5)", textAlign: "center" }}>
          <div>
            <div style={{ width: 80, height: 80, margin: "0 auto 14px", borderRadius: "50%", background: "rgba(0,224,138,.1)", border: "1px solid rgba(0,224,138,.3)", display: "grid", placeItems: "center" }}>
              <IconLive size={36} stroke="var(--whale-green)"/>
            </div>
            <div style={{ fontSize: 14, color: "rgba(255,255,255,.7)" }}>Camera preview</div>
            <div style={{ fontSize: 12, marginTop: 4 }}>Tap below to start broadcasting</div>
          </div>
        </div>

        {/* Side controls */}
        <div style={{ position: "absolute", right: 14, bottom: 220, display: "flex", flexDirection: "column", gap: 12 }}>
          {[
            { I: IconMic, on: audio, fn: () => setAudio(a => !a) },
            { I: IconImage, on: true },
            { I: IconSparkles, on: false },
            { I: IconSettings, on: false },
          ].map((b, i) => {
            const I = b.I;
            return (
              <button key={i} onClick={b.fn} style={{ width: 44, height: 44, borderRadius: "50%", background: b.on ? "rgba(0,224,138,.2)" : "rgba(0,0,0,.5)", border: b.on ? "1px solid var(--whale-green)" : "1px solid rgba(255,255,255,.15)", color: "#fff", display: "grid", placeItems: "center" }}>
                <I size={20}/>
              </button>
            );
          })}
        </div>
      </div>

      {/* Compose strip */}
      <div style={{ padding: "16px 16px 14px", background: "linear-gradient(180deg, transparent, rgba(0,0,0,.8) 30%)", color: "#fff" }}>
        <input
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="What are you live about?"
          style={{ width: "100%", padding: "12px 16px", borderRadius: 14, background: "rgba(255,255,255,.08)", border: "1px solid rgba(255,255,255,.15)", color: "#fff", fontSize: 14.5, marginBottom: 12 }}
        />
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          {["Trading", "AMA", "Whale Alerts", "Macro"].map(t => (
            <button key={t} style={{ padding: "6px 12px", borderRadius: 999, background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.12)", fontSize: 12, color: "rgba(255,255,255,.85)" }}>{t}</button>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: 6 }}>
            <button style={{ padding: "8px 14px", borderRadius: 999, background: "rgba(255,255,255,.08)", color: "#fff", fontSize: 12.5, fontWeight: 600, display:"inline-flex", alignItems:"center", gap: 6 }}><IconGlobe size={14}/> Public</button>
            <button style={{ padding: "8px 14px", borderRadius: 999, background: "rgba(245,194,73,.15)", color: "var(--whale-gold)", fontSize: 12.5, fontWeight: 600, display:"inline-flex", alignItems:"center", gap: 6 }}><IconWallet size={14}/> Tips on</button>
          </div>
          <button style={{ padding: "12px 26px", borderRadius: 999, background: "linear-gradient(135deg, #FF5C7A, #C9295A)", color: "#fff", fontSize: 14, fontWeight: 800, letterSpacing: ".04em", boxShadow: "0 10px 30px -8px rgba(255,92,122,.6)" }}>
            GO LIVE
          </button>
        </div>
      </div>
    </div>
  );
};

const SettingsScreen = ({ go, theme, setTheme }) => {
  const sections = [
    {
      title: "Account",
      items: [
        { label: "Your account", I: IconUser, sub: "@whalewatcher" },
        { label: "Privacy & safety", I: IconLock },
        { label: "Notifications", I: IconBell, sub: "12 unread" },
      ],
    },
    {
      title: "Wallet",
      items: [
        { label: "Connected wallets", I: IconWallet, sub: "1 wallet" },
        { label: "Tipping", I: IconHeart, sub: "Enabled" },
        { label: "Whale alerts", I: IconFire, sub: "Custom" },
      ],
    },
    {
      title: "Display",
      items: [
        { label: "Appearance", I: IconSparkles, sub: theme === "dark" ? "Dark" : "Light", action: () => setTheme(theme === "dark" ? "light" : "dark") },
        { label: "Accessibility", I: IconGlobe },
      ],
    },
  ];
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <PageHeader onBack={() => go("discover")} title="Settings"/>
      <div className="feed">
        {sections.map(sec => (
          <div key={sec.title}>
            <div style={{ padding: "16px 16px 6px", fontSize: 11, fontWeight: 800, letterSpacing: ".1em", color: "var(--text-4)", textTransform: "uppercase" }}>{sec.title}</div>
            {sec.items.map(it => {
              const I = it.I;
              return (
                <button key={it.label} onClick={it.action} style={{ width: "100%", textAlign: "left", padding: "14px 16px", display: "flex", alignItems: "center", gap: 14, borderBottom: "1px solid var(--line-soft)" }}>
                  <I size={20} stroke="var(--text-2)"/>
                  <span style={{ flex: 1, fontSize: 15, fontWeight: 600 }}>{it.label}</span>
                  {it.sub && <span style={{ fontSize: 12.5, color: "var(--text-3)" }}>{it.sub}</span>}
                  <IconChevronRight size={18} stroke="var(--text-3)"/>
                </button>
              );
            })}
          </div>
        ))}
        <div style={{ padding: "20px 16px 8px" }}>
          <button style={{ width: "100%", padding: "14px", borderRadius: 14, background: "rgba(255,92,122,.08)", color: "var(--like)", fontSize: 14.5, fontWeight: 700 }}>Log out</button>
        </div>
        <div style={{ padding: "12px 16px 24px", textAlign: "center", fontSize: 11.5, color: "var(--text-4)" }}>
          Whales Social v1.0.4 · Built with 🐋
        </div>
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const ProfileScreen = ({ go, openMenu }) => {
  const [tab, setTab] = React.useState("posts");
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ position: "relative", flexShrink: 0 }}>
        {/* cover */}
        <div style={{ height: 130, background:
          "radial-gradient(80% 100% at 0% 0%, rgba(0,224,138,.4), transparent 50%), radial-gradient(80% 100% at 100% 100%, rgba(245,194,73,.3), transparent 50%), linear-gradient(135deg, #0E1218, #1B2230)"
        }}/>
        <button className="icon-btn" onClick={() => go("discover")} style={{ position: "absolute", top: 12, left: 12, background: "rgba(0,0,0,.5)", color: "#fff" }}><IconArrowLeft size={20}/></button>
        <button className="icon-btn" onClick={openMenu} style={{ position: "absolute", top: 12, right: 12, background: "rgba(0,0,0,.5)", color: "#fff" }}><IconMore size={20}/></button>
        {/* avatar */}
        <div style={{ position: "absolute", left: 16, bottom: -36, padding: 4, background: "var(--bg)", borderRadius: "50%" }}>
          <div style={{ width: 80, height: 80, borderRadius: "50%", background: "linear-gradient(135deg,#00E08A,#009B5C)", color: "#021A0F", display: "grid", placeItems: "center", fontSize: 28, fontWeight: 800, fontFamily: "var(--font-display)" }}>WW</div>
        </div>
        <button style={{ position: "absolute", right: 14, bottom: -36 + 26, padding: "8px 16px", borderRadius: 999, background: "var(--text)", color: "var(--bg)", fontSize: 13, fontWeight: 700 }}>Edit profile</button>
      </div>

      <div style={{ padding: "44px 16px 14px", borderBottom: "1px solid var(--line)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 19, fontWeight: 800, fontFamily: "var(--font-display)" }}>Whale Watcher</span>
          <span style={{ color: "var(--whale-green)" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14 4l2.5-.5.5 2.5 2.5.5-.5 2.5L21 11l-1.5 2 1.5 2-2 .5-.5 2.5-2.5-.5L14 20l-2-1.5L10 20l-2-2-2.5.5-.5-2.5L2.5 15 4 13l-1.5-2L4 9l.5-2.5L7 4l.5-2.5L10 4z M9.5 12.5l2 2 4-4.5"/></svg>
          </span>
          <span style={{ fontSize: 10, fontWeight: 800, color: "#3a2a07", background: "linear-gradient(135deg,#FFD66E,#C99A1F)", padding: "2px 6px", borderRadius: 4, letterSpacing: ".05em" }}>WHALE</span>
        </div>
        <div style={{ fontSize: 14, color: "var(--text-3)", marginTop: 1 }}>@whalewatcher</div>
        <div style={{ fontSize: 14.5, marginTop: 10, lineHeight: 1.4 }}>
          on-chain analyst tracking the biggest wallets in crypto. <span style={{ color: "var(--whale-green)" }}>#alpha</span> not advice.
        </div>
        <div style={{ display: "flex", gap: 14, marginTop: 12, fontSize: 13, color: "var(--text-3)" }}>
          <span>📍 Decentraland</span>
          <span>🔗 whales.social/ww</span>
        </div>
        <div style={{ display: "flex", gap: 18, marginTop: 12, fontSize: 13.5 }}>
          <span><b style={{ color: "var(--text)" }}>284</b> <span style={{ color: "var(--text-3)" }}>Following</span></span>
          <span><b style={{ color: "var(--text)" }}>12.4K</b> <span style={{ color: "var(--text-3)" }}>Followers</span></span>
          <span><b style={{ color: "var(--whale-gold)" }}>2.84 ETH</b> <span style={{ color: "var(--text-3)" }}>tipped</span></span>
        </div>
      </div>

      <div className="tab-strip">
        {["posts", "replies", "media", "tips"].map(t => (
          <button key={t} className={"tab-strip-item" + (tab === t ? " active" : "")} onClick={() => setTab(t)}>{t.charAt(0).toUpperCase() + t.slice(1)}</button>
        ))}
      </div>

      <div className="feed">
        {POSTS.slice(0, 3).map(p => <PostCard key={p.id} post={{...p, person: PEOPLE.me}} onOpen={(p) => go("post-detail", { post: p })}/>)}
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const PostDetailScreen = ({ go, post }) => {
  const p = post || POSTS[0];
  const replies = [
    { ...POSTS[1], time: "8m" },
    { ...POSTS[5], time: "12m" },
  ];
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <PageHeader onBack={() => go("discover")} title="Post"/>
      <div className="feed">
        {/* main post — bigger layout */}
        <article style={{ padding: "16px 16px 14px", borderBottom: "1px solid var(--line-soft)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <Avatar p={p.person} size={48}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 14.5, fontWeight: 700 }}>
                {p.person.name}
                {p.person.verified && <span style={{ color: "var(--whale-green)" }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14 4l2.5-.5.5 2.5 2.5.5-.5 2.5L21 11l-1.5 2 1.5 2-2 .5-.5 2.5-2.5-.5L14 20l-2-1.5L10 20l-2-2-2.5.5-.5-2.5L2.5 15 4 13l-1.5-2L4 9l.5-2.5L7 4l.5-2.5L10 4z"/></svg>
                </span>}
              </div>
              <div style={{ fontSize: 13, color: "var(--text-3)" }}>{p.person.handle}</div>
            </div>
            <button className="icon-btn"><IconMore size={20}/></button>
          </div>
          <div style={{ fontSize: 18, lineHeight: 1.45, fontWeight: 400 }}>{p.body}</div>
          <div style={{ fontSize: 13, color: "var(--text-3)", marginTop: 14, paddingBottom: 12, borderBottom: "1px solid var(--line-soft)" }}>
            9:14 AM · Apr 24, 2026 · <b style={{ color: "var(--text-2)" }}>{(p.stats.views / 1000).toFixed(0)}K</b> Views
          </div>
          <div style={{ display: "flex", gap: 18, padding: "12px 0", fontSize: 13, color: "var(--text-3)", borderBottom: "1px solid var(--line-soft)" }}>
            <span><b style={{ color: "var(--text)" }}>{(p.stats.reposts / 1000).toFixed(1)}K</b> Reposts</span>
            <span><b style={{ color: "var(--text)" }}>{(p.stats.likes / 1000).toFixed(1)}K</b> Likes</span>
            <span><b style={{ color: "var(--whale-gold)" }}>0.42 ETH</b> Tipped</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-around", padding: "12px 0 4px", color: "var(--text-3)" }}>
            <button className="icon-btn"><IconReply size={22}/></button>
            <button className="icon-btn"><IconRepost size={22}/></button>
            <button className="icon-btn"><IconHeart size={22}/></button>
            <button className="icon-btn"><IconBookmark size={22}/></button>
            <button className="icon-btn"><IconShare size={22}/></button>
          </div>
        </article>
        <div style={{ padding: "10px 16px", display: "grid", gridTemplateColumns: "32px 1fr auto", gap: 10, alignItems: "center", borderBottom: "1px solid var(--line-soft)" }}>
          <Avatar p={PEOPLE.me} size={32}/>
          <input placeholder="Post your reply..." style={{ fontSize: 14, color: "var(--text-3)" }}/>
          <button style={{ padding: "6px 14px", borderRadius: 999, background: "var(--whale-green)", color: "#021A0F", fontSize: 13, fontWeight: 700 }}>Reply</button>
        </div>
        {replies.map(r => <PostCard key={r.id} post={r}/>)}
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const ComposeScreen = ({ go, onPost }) => {
  const [text, setText] = React.useState("");
  const max = 280;
  const remaining = max - text.length;
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "12px 16px", display: "flex", alignItems: "center", borderBottom: "1px solid var(--line)" }}>
        <button onClick={() => go("discover")} style={{ fontSize: 15, color: "var(--text-2)" }}>Cancel</button>
        <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 10px", borderRadius: 999, background: "var(--bg-elev)", border: "1px solid var(--line)", fontSize: 12, color: "var(--text-2)" }}>
            <IconGlobe size={13}/> Public
          </span>
          <button onClick={() => { onPost(); go("discover"); }} disabled={!text.trim()} style={{ padding: "8px 18px", borderRadius: 999, background: text.trim() ? "linear-gradient(135deg,#00E08A,#009B5C)" : "var(--bg-elev)", color: text.trim() ? "#021A0F" : "var(--text-3)", fontSize: 14, fontWeight: 700, opacity: text.trim() ? 1 : 0.6 }}>Post</button>
        </span>
      </div>
      <div style={{ padding: "14px 16px", display: "flex", gap: 12, flex: 1, overflow: "hidden" }}>
        <Avatar p={PEOPLE.me} size={44}/>
        <textarea
          autoFocus
          value={text}
          onChange={e => setText(e.target.value.slice(0, max))}
          placeholder="What's the alpha?"
          style={{ flex: 1, fontSize: 18, lineHeight: 1.4, resize: "none", height: "100%", color: "var(--text)" }}
        />
      </div>
      <div style={{ padding: "10px 16px 14px", borderTop: "1px solid var(--line)", display: "flex", alignItems: "center", gap: 4 }}>
        {[IconImage, IconGif, IconPoll, IconSparkles].map((I, i) => (
          <button key={i} className="icon-btn" style={{ color: "var(--whale-green)" }}><I size={20}/></button>
        ))}
        <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ position: "relative", width: 22, height: 22 }}>
            <svg width="22" height="22" viewBox="0 0 22 22">
              <circle cx="11" cy="11" r="9" fill="none" stroke="var(--line)" strokeWidth="2"/>
              <circle cx="11" cy="11" r="9" fill="none" stroke={remaining < 20 ? "var(--like)" : "var(--whale-green)"} strokeWidth="2" strokeLinecap="round" strokeDasharray={`${56.5 * (text.length / max)} 56.5`} transform="rotate(-90 11 11)"/>
            </svg>
          </span>
          <span style={{ fontSize: 12, color: remaining < 20 ? "var(--like)" : "var(--text-3)" }}>{remaining}</span>
        </span>
      </div>
    </div>
  );
};

// Bookmarks (lightweight)
const BookmarksScreen = ({ go }) => (
  <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
    <PageHeader onBack={() => go("discover")} title="Bookmarks" sub="@whalewatcher"/>
    <div className="feed">
      {POSTS.slice(0, 4).map(p => <PostCard key={p.id} post={p} onOpen={(p) => go("post-detail", { post: p })}/>)}
      <div className="feed-bottom-pad"/>
    </div>
  </div>
);

// Following list (separate from feed)
const FollowingScreen = ({ go }) => (
  <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
    <PageHeader onBack={() => go("discover")} title="Following" sub="@whalewatcher"/>
    <div className="feed">
      {Object.values(PEOPLE).filter(p => p.id !== "me").map(p => (
        <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: "1px solid var(--line-soft)" }}>
          <Avatar p={p} size={44}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 700, fontSize: 14.5, display:"flex", alignItems:"center", gap: 4 }}>
              {p.name}
              {p.verified && <span style={{ color: "var(--whale-green)" }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14 4l2.5-.5.5 2.5 2.5.5-.5 2.5L21 11l-1.5 2 1.5 2-2 .5-.5 2.5-2.5-.5L14 20l-2-1.5L10 20l-2-2-2.5.5-.5-2.5L2.5 15 4 13l-1.5-2L4 9l.5-2.5L7 4l.5-2.5L10 4z"/></svg>
              </span>}
            </div>
            <div style={{ fontSize: 13, color: "var(--text-3)" }}>{p.handle}</div>
          </div>
          <button style={{ padding: "8px 14px", borderRadius: 999, background: "transparent", color: "var(--text)", border: "1px solid var(--line)", fontSize: 13, fontWeight: 700 }}>Following</button>
        </div>
      ))}
      <div className="feed-bottom-pad"/>
    </div>
  </div>
);

Object.assign(window, { WalletScreen, GoLiveScreen, SettingsScreen, ProfileScreen, PostDetailScreen, ComposeScreen, BookmarksScreen, FollowingScreen });
