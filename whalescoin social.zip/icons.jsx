// Whales Social — icon set (custom, line, 24px viewbox)
const Icon = ({ d, size = 22, fill, stroke = "currentColor", sw = 1.8, children, viewBox = "0 0 24 24" }) => (
  <svg width={size} height={size} viewBox={viewBox} fill={fill || "none"} stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    {d ? <path d={d} /> : children}
  </svg>
);

const IconHome = (p) => (
  <Icon {...p}>
    <path d="M3.5 11.2 12 4l8.5 7.2V20a1 1 0 0 1-1 1h-4.5v-6h-6v6H4.5a1 1 0 0 1-1-1z" />
  </Icon>
);
const IconCompass = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="m15.5 8.5-2 5.5-5.5 2 2-5.5z" />
  </Icon>
);
const IconBell = (p) => (
  <Icon {...p}>
    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8" />
    <path d="M10.5 21a1.5 1.5 0 0 0 3 0" />
  </Icon>
);
const IconMail = (p) => (
  <Icon {...p}>
    <rect x="3" y="5" width="18" height="14" rx="2.5" />
    <path d="m4 7 8 6 8-6" />
  </Icon>
);
const IconPlus = (p) => (
  <Icon {...p}>
    <path d="M12 5v14M5 12h14" />
  </Icon>
);
const IconSearch = (p) => (
  <Icon {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </Icon>
);
const IconWallet = (p) => (
  <Icon {...p}>
    <rect x="3" y="6" width="18" height="13" rx="2.5" />
    <path d="M3 9h18" />
    <circle cx="16.5" cy="13.5" r="1.2" fill="currentColor" stroke="none" />
  </Icon>
);
const IconLive = (p) => (
  <Icon {...p}>
    <rect x="2" y="6" width="14" height="12" rx="2" />
    <path d="m22 7-6 5 6 5z" />
  </Icon>
);
const IconBookmark = (p) => (
  <Icon {...p}>
    <path d="M6 4h12v17l-6-4-6 4z" />
  </Icon>
);
const IconSettings = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
  </Icon>
);
const IconUser = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21a8 8 0 0 1 16 0" />
  </Icon>
);
const IconHeart = ({ filled, ...p }) => (
  <Icon {...p} fill={filled ? "currentColor" : "none"}>
    <path d="M12 20s-7-4.5-9-9.5C1.5 6 5 3 8 4.5c1.7.8 3 2.5 4 4 1-1.5 2.3-3.2 4-4C19 3 22.5 6 21 10.5 19 15.5 12 20 12 20" />
  </Icon>
);
const IconReply = (p) => (
  <Icon {...p}>
    <path d="M21 15c0 2-1.5 3.5-3.5 3.5H8l-4 3.5V7.5C4 5.5 5.5 4 7.5 4h10C19.5 4 21 5.5 21 7.5z" />
  </Icon>
);
const IconRepost = (p) => (
  <Icon {...p}>
    <path d="M3 9V7a3 3 0 0 1 3-3h11M21 15v2a3 3 0 0 1-3 3H7" />
    <path d="m6 12-3 3 3 3M18 12l3-3-3-3" />
  </Icon>
);
const IconShare = (p) => (
  <Icon {...p}>
    <path d="M12 4v12" />
    <path d="m7 9 5-5 5 5" />
    <path d="M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5" />
  </Icon>
);
const IconViews = (p) => (
  <Icon {...p}>
    <path d="M3 21V10M9 21V4M15 21v-7M21 21V8" />
  </Icon>
);
const IconArrowLeft = (p) => (
  <Icon {...p}>
    <path d="M19 12H5M12 5l-7 7 7 7" />
  </Icon>
);
const IconMore = (p) => (
  <Icon {...p}>
    <circle cx="6" cy="12" r="1.4" fill="currentColor" stroke="none" />
    <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
    <circle cx="18" cy="12" r="1.4" fill="currentColor" stroke="none" />
  </Icon>
);
const IconCheck = (p) => (
  <Icon {...p}>
    <path d="m5 12 5 5L20 7" />
  </Icon>
);
const IconChevronRight = (p) => (
  <Icon {...p}>
    <path d="m9 6 6 6-6 6" />
  </Icon>
);
const IconWhale = (p) => (
  // Custom whale glyph
  <Icon {...p} viewBox="0 0 24 24">
    <path d="M3 14c0-3 2.5-6 6.5-6 3 0 5 1.5 6 3 1-1 2.5-2 4-2 1 0 1.5.5 1.5.5s-.5 1-2 2c-.5.3-.5.7 0 1 1.5.7 2 2 2 3 0 0-1 1-2.5.5-1-.3-1.5-.7-2-1-1 1.5-3 2.5-6 2.5-2.5 0-4.5-.5-6-2-1 .5-2 .5-2.5 0 0-.5.5-1 1-1.5z" />
    <circle cx="9" cy="11.5" r=".7" fill="currentColor" stroke="none" />
  </Icon>
);
const IconFire = (p) => (
  <Icon {...p}>
    <path d="M12 22c4 0 7-3 7-7 0-3-2-5-3-6 0 2-1 3-2 3 0-3-2-6-5-8 0 4-3 5-3 9s3 9 6 9z" />
  </Icon>
);
const IconLock = (p) => (
  <Icon {...p}>
    <rect x="5" y="11" width="14" height="10" rx="2" />
    <path d="M8 11V8a4 4 0 1 1 8 0v3" />
  </Icon>
);
const IconImage = (p) => (
  <Icon {...p}>
    <rect x="3" y="4" width="18" height="16" rx="2" />
    <circle cx="9" cy="10" r="1.5" />
    <path d="m4 18 5-5 5 4 3-3 3 3" />
  </Icon>
);
const IconGif = (p) => (
  <Icon {...p}>
    <rect x="3" y="5" width="18" height="14" rx="3" />
    <path d="M8 9v6M11 9v6h2.5M16 9v6M16 12h2" strokeWidth="1.6" />
  </Icon>
);
const IconPoll = (p) => (
  <Icon {...p}>
    <path d="M5 20V8M11 20V4M17 20v-8" strokeWidth="2.5" />
  </Icon>
);
const IconSparkles = (p) => (
  <Icon {...p}>
    <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.5 5.5l2 2M16.5 16.5l2 2M5.5 18.5l2-2M16.5 7.5l2-2" />
  </Icon>
);
const IconGlobe = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
  </Icon>
);
const IconMic = (p) => (
  <Icon {...p}>
    <rect x="9" y="3" width="6" height="12" rx="3" />
    <path d="M5 12a7 7 0 0 0 14 0M12 19v3" />
  </Icon>
);
const IconCopy = (p) => (
  <Icon {...p}>
    <rect x="8" y="8" width="13" height="13" rx="2" />
    <path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3" />
  </Icon>
);
const IconQr = (p) => (
  <Icon {...p}>
    <rect x="3" y="3" width="7" height="7" />
    <rect x="14" y="3" width="7" height="7" />
    <rect x="3" y="14" width="7" height="7" />
    <path d="M14 14h3v3M21 14v3M17 17v4M14 21h3" />
  </Icon>
);
const IconLanguage = (p) => (
  <Icon {...p}>
    <path d="M3 5h12M9 3v2M11 5c0 4.5-3 9-7 11M6 9c0 3 3 6 8 7"/>
    <path d="m13 21 4-10 4 10M14.5 17h5"/>
  </Icon>
);
const IconHelp = (p) => (
  <Icon {...p}>
    <circle cx="12" cy="12" r="9"/>
    <path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.8.4-1 1-1 1.7"/>
    <circle cx="12" cy="17" r=".8" fill="currentColor" stroke="none"/>
  </Icon>
);
const IconShield = (p) => (
  <Icon {...p}>
    <path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/>
    <path d="m9 12 2 2 4-4"/>
  </Icon>
);
const IconLogout = (p) => (
  <Icon {...p}>
    <path d="M10 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h4"/>
    <path d="m16 8 4 4-4 4M20 12H10"/>
  </Icon>
);
const IconStar = (p) => (
  <Icon {...p}>
    <path d="m12 3 2.7 5.7 6.3.9-4.5 4.4 1 6.3L12 17.3 6.5 20.3l1-6.3L3 9.6l6.3-.9z"/>
  </Icon>
);
const IconCheckSm = (p) => (
  <Icon {...p}>
    <path d="m5 12 5 5L20 7"/>
  </Icon>
);

Object.assign(window, {
  IconHome, IconCompass, IconBell, IconMail, IconPlus, IconSearch,
  IconWallet, IconLive, IconBookmark, IconSettings, IconUser,
  IconHeart, IconReply, IconRepost, IconShare, IconViews, IconArrowLeft,
  IconMore, IconCheck, IconChevronRight, IconWhale, IconFire, IconLock,
  IconImage, IconGif, IconPoll, IconSparkles, IconGlobe, IconMic, IconCopy, IconQr,
  IconLanguage, IconHelp, IconShield, IconLogout, IconStar, IconCheckSm,
});
