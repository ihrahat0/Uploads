// Whales Social — main feed screens

const DiscoverScreen = ({ go, openMenu, openCompose, onAction }) => {
  const [tab, setTab] = React.useState("for-you");
  const list = tab === "for-you" ? POSTS : FOLLOWING_POSTS;
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <AppHeader onMenu={openMenu} onSparkle={() => {}} sparkleBadge/>
      <div className="tab-strip">
        <button className={"tab-strip-item" + (tab === "for-you" ? " active" : "")} onClick={() => setTab("for-you")}>For you</button>
        <button className={"tab-strip-item" + (tab === "following" ? " active" : "")} onClick={() => setTab("following")}>Following</button>
        <button className={"tab-strip-item" + (tab === "whales" ? " active" : "")} onClick={() => setTab("whales")}>🐋 Whales</button>
      </div>
      <div className="feed">
        {tab !== "whales" && (
          <div className="composer-inline" onClick={openCompose}>
            <Avatar p={PEOPLE.me} size={40}/>
            <div className="ci-input">What's the alpha?</div>
          </div>
        )}
        {tab === "whales" && (
          <div className="whale-banner">
            <div className="wb-icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M3 14c0-3 2.5-6 6.5-6 3 0 5 1.5 6 3 1-1 2.5-2 4-2 1 0 1.5.5 1.5.5s-.5 1-2 2c-.5.3-.5.7 0 1 1.5.7 2 2 2 3 0 0-1 1-2.5.5-1-.3-1.5-.7-2-1-1 1.5-3 2.5-6 2.5-2.5 0-4.5-.5-6-2-1 .5-2 .5-2.5 0 0-.5.5-1 1-1.5z"/></svg>
            </div>
            <div>
              <div className="wb-title">Whale of the day</div>
              <div className="wb-name">@punk6529 moved 240 ETH</div>
              <div className="wb-meta">to a new cold wallet · 2h ago</div>
            </div>
            <button className="wb-cta">Track</button>
          </div>
        )}
        {list.map(p => (
          <PostCard key={p.id} post={p} onOpen={(p) => go("post-detail", { post: p })} onAction={onAction}/>
        ))}
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const ExploreScreen = ({ openMenu, go }) => {
  const [q, setQ] = React.useState("");
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ padding: "10px 14px 12px", display: "flex", alignItems: "center", gap: 10, borderBottom: "1px solid var(--line)" }}>
        <button className="avatar-btn" onClick={openMenu}>
          <div style={{ width: "100%", height: "100%", borderRadius: "50%", background: "linear-gradient(135deg,#00E08A,#009B5C)", color: "#021A0F", display:"grid", placeItems:"center", fontWeight:700, fontSize:13 }}>WW</div>
        </button>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, background: "var(--bg-elev)", border: "1px solid var(--line)", borderRadius: 999, padding: "10px 14px" }}>
          <IconSearch size={18} stroke="var(--text-3)"/>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search whales, tokens, posts" style={{ flex: 1, fontSize: 14 }}/>
        </div>
        <button className="icon-btn"><IconSettings size={20}/></button>
      </div>
      <div className="feed">
        {/* Live alerts strip */}
        <div style={{ padding: "14px 16px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: ".1em", color: "var(--whale-gold)", textTransform: "uppercase" }}>🐋 Live whale alerts</span>
          <span style={{ fontSize: 12, color: "var(--text-3)" }}>last 1h</span>
        </div>
        <div style={{ display: "flex", overflowX: "auto", gap: 10, padding: "4px 16px 16px", scrollbarWidth: "none" }}>
          {[
            { tk: "ETH", amt: "4,200", usd: "$14.6M", who: "0x7a3...e21", up: true },
            { tk: "BTC", amt: "180", usd: "$12.2M", who: "0x4f2...c11", up: true },
            { tk: "SOL", amt: "82,400", usd: "$11.8M", who: "0x9b8...a04", up: false },
            { tk: "USDC", amt: "20M", usd: "$20.0M", who: "Coinbase", up: true },
          ].map((a, i) => (
            <div key={i} style={{ flex: "0 0 180px", padding: 12, borderRadius: 14, background: "var(--bg-elev)", border: "1px solid var(--line)" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <span style={{ width: 26, height: 26, borderRadius: "50%", background: "var(--bg-elev-2)", color: "var(--whale-gold)", display: "grid", placeItems: "center", fontFamily: "var(--font-mono)", fontSize: 10, fontWeight: 700 }}>{a.tk}</span>
                <span style={{ fontSize: 10, color: a.up ? "var(--whale-green)" : "var(--like)", fontWeight: 700 }}>{a.up ? "↑ IN" : "↓ OUT"}</span>
              </div>
              <div style={{ fontFamily: "var(--font-mono)", fontWeight: 700, fontSize: 16 }}>{a.amt} {a.tk}</div>
              <div style={{ fontSize: 11.5, color: "var(--text-3)", marginTop: 2 }}>≈ {a.usd}</div>
              <div style={{ fontSize: 11, color: "var(--text-4)", marginTop: 6, fontFamily: "var(--font-mono)" }}>{a.who}</div>
            </div>
          ))}
        </div>

        {/* Trending */}
        <div style={{ padding: "8px 16px 8px", fontSize: 17, fontWeight: 700, fontFamily: "var(--font-display)" }}>Trending now</div>
        {TREND_TOPICS.map((t, i) => (
          <button key={i} style={{ width: "100%", textAlign: "left", padding: "12px 16px", borderBottom: "1px solid var(--line-soft)", display: "flex", alignItems: "flex-start", gap: 12 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11.5, color: "var(--text-3)", marginBottom: 2 }}>{i + 1} · {t.cat}</div>
              <div style={{ fontSize: 15, fontWeight: 700, fontFamily: t.tag.startsWith("$") ? "var(--font-mono)" : undefined, color: t.tag.startsWith("$") ? "var(--whale-gold)" : "var(--text)" }}>{t.tag}</div>
              <div style={{ fontSize: 12, color: "var(--text-3)", marginTop: 2 }}>{t.posts}{t.price ? ` · ${t.price} (${t.change})` : ""}</div>
            </div>
            <button className="icon-btn" style={{ width: 28, height: 28 }}><IconMore size={16}/></button>
          </button>
        ))}

        {/* Who to follow */}
        <div style={{ padding: "16px 16px 8px", fontSize: 17, fontWeight: 700, fontFamily: "var(--font-display)" }}>Whales to follow</div>
        {SUGGESTED.map(p => (
          <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: "1px solid var(--line-soft)" }}>
            <Avatar p={p} size={44}/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontWeight: 700, fontSize: 14.5, display:"flex", alignItems:"center", gap: 4 }}>
                {p.name}
                {p.verified && <span style={{ color: "var(--whale-green)" }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14 4l2.5-.5.5 2.5 2.5.5-.5 2.5L21 11l-1.5 2 1.5 2-2 .5-.5 2.5-2.5-.5L14 20l-2-1.5L10 20l-2-2-2.5.5-.5-2.5L2.5 15 4 13l-1.5-2L4 9l.5-2.5L7 4l.5-2.5L10 4z"/></svg>
                </span>}
              </div>
              <div style={{ fontSize: 13, color: "var(--text-3)" }}>{p.handle}</div>
            </div>
            <button style={{ padding: "8px 16px", borderRadius: 999, background: "var(--text)", color: "var(--bg)", fontSize: 13, fontWeight: 700 }}>Follow</button>
          </div>
        ))}
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const NotificationsScreen = ({ openMenu, go }) => {
  const [tab, setTab] = React.useState("all");
  const renderActors = (n) => {
    return (
      <div style={{ display: "flex", marginBottom: 8 }}>
        {n.actors.map((a, i) => (
          <div key={a.id} style={{ marginLeft: i === 0 ? 0 : -10, border: "2px solid var(--bg)", borderRadius: "50%" }}>
            <Avatar p={a} size={32}/>
          </div>
        ))}
      </div>
    );
  };
  const iconFor = (type) => {
    const map = {
      like: { I: IconHeart, color: "var(--like)", filled: true },
      follow: { I: IconUser, color: "var(--whale-green)" },
      repost: { I: IconRepost, color: "var(--repost)" },
      tip: { I: IconWallet, color: "var(--whale-gold)" },
      mention: { I: IconReply, color: "var(--text)" },
      live: { I: IconLive, color: "var(--like)" },
    };
    return map[type] || map.mention;
  };

  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <AppHeader onMenu={openMenu} title="Notifications"/>
      <div className="tab-strip">
        <button className={"tab-strip-item" + (tab === "all" ? " active" : "")} onClick={() => setTab("all")}>All</button>
        <button className={"tab-strip-item" + (tab === "mentions" ? " active" : "")} onClick={() => setTab("mentions")}>Mentions</button>
        <button className={"tab-strip-item" + (tab === "tips" ? " active" : "")} onClick={() => setTab("tips")}>Tips</button>
      </div>
      <div className="feed">
        {NOTIFICATIONS.filter(n => tab === "all" || (tab === "mentions" && n.type === "mention") || (tab === "tips" && n.type === "tip")).map(n => {
          const meta = iconFor(n.type);
          const I = meta.I;
          return (
            <div key={n.id} style={{ display: "grid", gridTemplateColumns: "32px 1fr auto", gap: 12, padding: "14px 16px", borderBottom: "1px solid var(--line-soft)", alignItems: "flex-start" }}>
              <div style={{ width: 32, height: 32, display: "grid", placeItems: "center", color: meta.color }}>
                <I size={22} filled={meta.filled}/>
              </div>
              <div>
                {renderActors(n)}
                <div style={{ fontSize: 14, lineHeight: 1.4 }}>
                  <b>{n.actors[0].name}</b>
                  {n.actors.length > 1 && <span style={{ color: "var(--text-2)" }}>{`, ${n.actors[1].name}`}{n.extraCount ? ` and ${n.extraCount} others` : ""}</span>}
                  <span style={{ color: "var(--text-2)" }}> {n.body}</span>
                </div>
              </div>
              <span style={{ fontSize: 12, color: "var(--text-3)", whiteSpace: "nowrap" }}>{n.time}</span>
            </div>
          );
        })}
        <div className="feed-bottom-pad"/>
      </div>
    </div>
  );
};

const MessagesScreen = ({ openMenu, go }) => (
  <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
    <AppHeader onMenu={openMenu} title="Messages"/>
    <div style={{ padding: "8px 16px 12px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, background: "var(--bg-elev)", border: "1px solid var(--line)", borderRadius: 999, padding: "10px 14px" }}>
        <IconSearch size={16} stroke="var(--text-3)"/>
        <input placeholder="Search messages" style={{ flex: 1, fontSize: 13.5 }}/>
      </div>
    </div>
    <div className="feed">
      {CONVERSATIONS.map(c => (
        <button key={c.id} onClick={() => go("dm-thread", { conv: c })} style={{ width: "100%", textAlign: "left", padding: "12px 16px", borderBottom: "1px solid var(--line-soft)", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ position: "relative" }}>
            <Avatar p={c.person} size={48}/>
            {c.online && <span style={{ position: "absolute", bottom: 0, right: 0, width: 12, height: 12, borderRadius: "50%", background: "var(--whale-green)", border: "2.5px solid var(--bg)" }}/>}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontWeight: 700, fontSize: 14.5 }}>{c.person.name}</span>
              {c.isBot && <span style={{ fontSize: 9.5, fontWeight: 800, padding: "1px 5px", borderRadius: 4, background: "var(--whale-green)", color: "#021A0F" }}>BOT</span>}
              <span style={{ marginLeft: "auto", fontSize: 12, color: "var(--text-3)" }}>{c.time}</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 2 }}>
              <span style={{ fontSize: 13.5, color: c.unread ? "var(--text)" : "var(--text-3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1, fontWeight: c.unread ? 600 : 400 }}>
                {c.last}
              </span>
              {c.unread > 0 && <span style={{ flexShrink: 0, minWidth: 20, height: 20, padding: "0 6px", borderRadius: 999, background: "var(--whale-green)", color: "#021A0F", fontSize: 11, fontWeight: 800, display: "grid", placeItems: "center" }}>{c.unread}</span>}
            </div>
          </div>
        </button>
      ))}
      <div className="feed-bottom-pad"/>
    </div>
    <button onClick={() => go("dm-thread", { conv: CONVERSATIONS[0] })} style={{ position: "absolute", bottom: 100, right: 18, width: 56, height: 56, borderRadius: "50%", background: "linear-gradient(135deg,#00E08A,#009B5C)", color: "#021A0F", display:"grid", placeItems:"center", boxShadow: "0 12px 30px -8px rgba(0,224,138,.5)", zIndex: 5 }}>
      <IconMail size={22} sw={2}/>
    </button>
  </div>
);

const DMThreadScreen = ({ go, conv }) => {
  const c = conv || CONVERSATIONS[0];
  const [msgs, setMsgs] = React.useState([
    { from: "them", text: "did you see that whale alert from earlier?", time: "9:32" },
    { from: "me", text: "the 4,200 ETH move? yeah crazy", time: "9:33" },
    { from: "them", text: "could be the same wallet that bought the 2024 dip", time: "9:34" },
    { from: "them", text: "lol fair, but the basis trade is still the cleanest play right now", time: "9:35" },
  ]);
  const [draft, setDraft] = React.useState("");
  const send = () => {
    if (!draft.trim()) return;
    setMsgs(m => [...m, { from: "me", text: draft, time: "9:41" }]);
    setDraft("");
    setTimeout(() => {
      setMsgs(m => [...m, { from: "them", text: "🐋", time: "9:41" }]);
    }, 800);
  };
  return (
    <div className="screen-enter" style={{ display: "flex", flexDirection: "column", height: "100%" }}>
      <PageHeader
        onBack={() => go("messages")}
        title={c.person.name}
        sub={c.online ? "online" : "last seen 2h ago"}
        right={<><button className="icon-btn"><IconLive size={20}/></button><button className="icon-btn"><IconMore size={20}/></button></>}
      />
      <div className="feed" style={{ padding: "16px 16px 12px", display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ alignSelf: "center", padding: "6px 12px", borderRadius: 999, background: "var(--bg-elev)", border: "1px solid var(--line)", fontSize: 11, color: "var(--text-3)" }}>
          🔒 End-to-end encrypted
        </div>
        {msgs.map((m, i) => {
          const mine = m.from === "me";
          return (
            <div key={i} style={{ display: "flex", justifyContent: mine ? "flex-end" : "flex-start", alignItems: "flex-end", gap: 8 }}>
              {!mine && <Avatar p={c.person} size={28}/>}
              <div style={{
                maxWidth: "72%",
                padding: "10px 14px",
                borderRadius: mine ? "20px 20px 4px 20px" : "20px 20px 20px 4px",
                background: mine ? "linear-gradient(135deg,#00E08A,#009B5C)" : "var(--bg-elev)",
                color: mine ? "#021A0F" : "var(--text)",
                border: mine ? "none" : "1px solid var(--line)",
                fontSize: 14.5, lineHeight: 1.4,
              }}>{m.text}</div>
            </div>
          );
        })}
        <div className="feed-bottom-pad" style={{ height: 80 }}/>
      </div>
      <div style={{ padding: "10px 12px 14px", borderTop: "1px solid var(--line)", background: "var(--bg)", display: "flex", alignItems: "center", gap: 8 }}>
        <button className="icon-btn"><IconImage size={22}/></button>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 6, background: "var(--bg-elev)", border: "1px solid var(--line)", borderRadius: 999, padding: "8px 14px" }}>
          <input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Message..." style={{ flex: 1, fontSize: 14 }}/>
          <button onClick={() => setDraft(d => d + " 🐋")} style={{ color: "var(--text-3)" }}>🐋</button>
        </div>
        <button onClick={send} style={{ width: 38, height: 38, borderRadius: "50%", background: draft.trim() ? "linear-gradient(135deg,#00E08A,#009B5C)" : "var(--bg-elev)", color: draft.trim() ? "#021A0F" : "var(--text-3)", display: "grid", placeItems: "center", border: draft.trim() ? "none" : "1px solid var(--line)" }}>
          <IconShare size={18} sw={2.2}/>
        </button>
      </div>
    </div>
  );
};

Object.assign(window, { DiscoverScreen, ExploreScreen, NotificationsScreen, MessagesScreen, DMThreadScreen });
