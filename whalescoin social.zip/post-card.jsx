// Post card component for Whales Social
const { useState } = React;

const PostStat = ({ icon, value, color, active, onClick, fillIcon }) => (
  <button onClick={onClick} className="row" style={{
    gap: 6, color: active ? color : 'var(--text-3)',
    transition: 'color 0.15s',
    padding: '4px 6px',
    margin: '-4px -6px',
    borderRadius: 8,
  }}>
    <span style={{ display: 'grid', placeItems: 'center' }} className={active ? 'liked-anim' : ''}>
      <Icon name={fillIcon || icon} size={18} stroke={1.8} />
    </span>
    {value !== undefined && value !== null && (
      <span style={{ fontSize: 12, fontWeight: 600, fontVariantNumeric: 'tabular-nums' }}>{typeof value === 'number' ? fmt(value) : value}</span>
    )}
  </button>
);

const PostAttachment = ({ post }) => {
  if (post.attachments?.[0]?.kind === 'link') {
    const a = post.attachments[0];
    return (
      <div style={{
        marginTop: 10,
        borderRadius: 'var(--r-md)',
        border: '1px solid var(--border)',
        overflow: 'hidden',
      }}>
        <div className="img-placeholder" style={{
          height: 160,
          background: `linear-gradient(135deg, oklch(0.35 0.12 ${a.img.hue}) 0%, oklch(0.2 0.08 ${a.img.hue + 40}) 100%)`,
          position: 'relative',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            display: 'grid', placeItems: 'center',
            color: 'rgba(255,255,255,0.3)', fontSize: 32, fontWeight: 800, letterSpacing: '-0.04em',
          }}>vitalik.eth</div>
        </div>
        <div style={{ padding: '10px 12px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', textTransform: 'lowercase' }}>{a.site}</div>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', marginTop: 2, lineHeight: 1.3 }}>{a.title}</div>
        </div>
      </div>
    );
  }
  if (post.image) {
    return (
      <div className="img-placeholder" style={{
        marginTop: 10,
        height: 200,
        borderRadius: 'var(--r-md)',
        border: '1px solid var(--border)',
        background: `linear-gradient(135deg, oklch(0.45 0.18 ${post.image.hue}) 0%, oklch(0.25 0.1 ${post.image.hue + 40}) 100%)`,
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: 600, letterSpacing: 1, textTransform: 'uppercase' }}>
          {post.image.label}
        </div>
      </div>
    );
  }
  if (post.chart) {
    const c = post.chart;
    const up = c.dir === 'up';
    return (
      <div style={{
        marginTop: 10,
        borderRadius: 'var(--r-md)',
        border: '1px solid var(--border)',
        background: 'var(--bg-elev-2)',
        padding: '14px 16px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 600 }}>{c.symbol}</div>
            <div style={{ fontSize: 22, fontWeight: 700, marginTop: 2, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.02em' }}>${c.price}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: up ? 'var(--whale-green)' : 'var(--whale-red)' }}>{c.change}</div>
          </div>
          <div style={{ marginTop: 8 }}>
            <Sparkline dir={c.dir} width={120} height={50} />
          </div>
        </div>
      </div>
    );
  }
  return null;
};

const PostCard = ({ post, onOpen }) => {
  const [liked, setLiked] = useState(false);
  const [reposted, setReposted] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const u = window.WhalesData.users[post.user];

  return (
    <article
      onClick={() => onOpen?.(post)}
      style={{
        padding: '14px 16px 10px',
        borderBottom: '1px solid var(--border)',
        cursor: 'pointer',
        position: 'relative',
      }}>
      {post.pinned && (
        <div className="row" style={{ gap: 6, fontSize: 12, color: 'var(--text-3)', marginBottom: 6, marginLeft: 28, fontWeight: 600 }}>
          <Icon name="pin" size={13} /> Pinned by Whale Watch
        </div>
      )}
      <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
        <Avatar user={post.user} size={42} showWhale />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="row" style={{ justifyContent: 'space-between', gap: 8, alignItems: 'flex-start' }}>
            <div style={{ minWidth: 0, flex: 1 }}>
              <UserName user={post.user} withTime time={post.time} />
            </div>
            <button onClick={(e) => e.stopPropagation()} className="icon-btn" style={{ width: 28, height: 28, marginRight: -8, marginTop: -4 }}>
              <Icon name="more" size={18} />
            </button>
          </div>
          {/* text */}
          <div style={{
            marginTop: 4,
            fontSize: 15,
            lineHeight: 1.42,
            color: 'var(--text)',
            letterSpacing: '-0.005em',
            wordBreak: 'break-word',
          }}>
            {linkifyText(post.text)}
          </div>
          <PostAttachment post={post} />
          {/* stats */}
          <div className="row" style={{ marginTop: 12, gap: 0, justifyContent: 'space-between' }}>
            <PostStat
              icon="reply"
              value={post.replies}
              onClick={(e) => { e.stopPropagation(); }}
            />
            <PostStat
              icon="repost"
              value={(post.reposts || 0) + (reposted ? 1 : 0)}
              active={reposted}
              color="var(--whale-green)"
              onClick={(e) => { e.stopPropagation(); setReposted(!reposted); }}
            />
            <PostStat
              icon={liked ? 'heart-fill' : 'heart'}
              value={(post.likes || 0) + (liked ? 1 : 0)}
              active={liked}
              color="var(--whale-red)"
              onClick={(e) => { e.stopPropagation(); setLiked(!liked); }}
            />
            <PostStat
              icon="tip"
              value={post.tipped ? `${post.tipped}` : ''}
              color="var(--whale-gold)"
              onClick={(e) => { e.stopPropagation(); }}
            />
            <PostStat
              icon="eye"
              value={post.views}
              onClick={(e) => { e.stopPropagation(); }}
            />
            <PostStat
              icon={bookmarked ? 'bookmark-fill' : 'bookmark'}
              active={bookmarked}
              color="var(--whale-blue)"
              onClick={(e) => { e.stopPropagation(); setBookmarked(!bookmarked); }}
            />
          </div>
        </div>
      </div>
    </article>
  );
};

// Highlight $TICKER, #hashtag, @handle in green/gold/blue
const linkifyText = (text) => {
  const tokens = text.split(/(\$[A-Z]{2,6}|#\w+|@[\w.]+)/g);
  return tokens.map((t, i) => {
    if (t.startsWith('$')) return <span key={i} style={{ color: 'var(--whale-gold)', fontWeight: 600 }}>{t}</span>;
    if (t.startsWith('#')) return <span key={i} style={{ color: 'var(--whale-green)', fontWeight: 600 }}>{t}</span>;
    if (t.startsWith('@')) return <span key={i} style={{ color: 'var(--whale-blue)', fontWeight: 600 }}>{t}</span>;
    return <span key={i}>{t}</span>;
  });
};

Object.assign(window, { PostCard, linkifyText });
