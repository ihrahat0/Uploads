// Reusable UI bits
const { useState, useEffect, useRef } = React;

// Verified badge
const Verified = ({ kind }) => kind ? (
  <span className={`whale-badge ${kind === 'emerald' ? 'emerald' : ''}`} title="Verified">
    {kind === 'gold' ? '🐋' : '✓'}
  </span>
) : null;

// Avatar
const Avatar = ({ initials, gradient, size = 44 }) => (
  <div className="post-avatar" style={{
    width: size, height: size, fontSize: size / 2.6,
    background: gradient || 'linear-gradient(135deg, #1a3530, #0e2622)'
  }}>
    {initials}
  </div>
);

// Format text with mentions/tags/tickers
const FormatText = ({ text }) => {
  const parts = text.split(/(\s+)/).map((w, i) => {
    if (/^@\w+/.test(w)) return <span key={i} className="mention">{w}</span>;
    if (/^#\w+/.test(w)) return <span key={i} className="tag">{w}</span>;
    if (/^\$[A-Z]{2,5}/.test(w)) return <span key={i} className="ticker">{w}</span>;
    return <React.Fragment key={i}>{w}</React.Fragment>;
  });
  return <span>{parts}</span>;
};

// Mini chart card embedded in post
const ChartCard = ({ chart }) => (
  <div className="post-media">
    <div className="post-chart">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 10 }}>
        <div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            ${chart.sym} · 24h
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.02em', marginTop: 2 }}>
            {chart.price}
          </div>
        </div>
        <div style={{
          fontSize: 13, fontWeight: 700, fontVariantNumeric: 'tabular-nums',
          color: chart.up ? 'var(--brand-emerald)' : 'var(--danger)',
          background: chart.up ? 'rgba(0,214,143,0.12)' : 'rgba(255,90,106,0.12)',
          padding: '4px 10px', borderRadius: 'var(--r-pill)',
        }}>
          {chart.change}
        </div>
      </div>
      <Spark data={chart.data} color={chart.up ? 'var(--brand-emerald)' : 'var(--danger)'} w={300} h={70} />
    </div>
  </div>
);

// Post card
const PostCard = ({ post, onLike, onRepost, onClick }) => (
  <div className="post" onClick={onClick}>
    <Avatar initials={post.initials} gradient={post.avatar} />
    <div className="post-body">
      <div className="post-head">
        <span className="post-name">{post.name}</span>
        <Verified kind={post.verified} />
        <span className="post-handle">@{post.handle}</span>
        <span className="post-dot">·</span>
        <span className="post-time">{post.time}</span>
      </div>
      <div className="post-text"><FormatText text={post.text} /></div>
      {post.chart && <ChartCard chart={post.chart} />}
      {post.image && (
        <div className="post-media">
          <div className="post-image" style={{ backgroundImage: post.image, position: 'relative' }}>
            {post.imageOverlay && (
              <div style={{
                position: 'absolute', inset: 0, padding: 24,
                display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
                background: 'linear-gradient(to top, rgba(0,0,0,0.6), transparent)'
              }}>
                <div style={{ fontSize: 11, color: 'var(--brand-gold)', letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 700 }}>
                  Pelagic Capital
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, color: '#fff', letterSpacing: '-0.02em', marginTop: 4 }}>
                  {post.imageOverlay}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      <div className="post-actions">
        <button className="post-action" onClick={(e) => { e.stopPropagation(); }}>
          <I.Comment size={18} /><span>{post.stats.c}</span>
        </button>
        <button className={`post-action ${post.reposted ? 'reposted' : ''}`}
                onClick={(e) => { e.stopPropagation(); onRepost && onRepost(post.id); }}>
          <I.Repost size={18} /><span>{post.stats.r + (post.reposted ? 1 : 0)}</span>
        </button>
        <button className={`post-action ${post.liked ? 'liked' : ''}`}
                onClick={(e) => { e.stopPropagation(); onLike && onLike(post.id); }}>
          <I.Heart size={18} fill={post.liked ? 'currentColor' : 'none'} />
          <span>{(post.stats.l + (post.liked ? 0.1 : 0)).toFixed(1)}K</span>
        </button>
        <button className="post-action" onClick={(e) => e.stopPropagation()}>
          <I.Chart size={18} /><span>{post.stats.v}</span>
        </button>
        <button className="post-action" onClick={(e) => e.stopPropagation()}>
          <I.Share size={18} />
        </button>
      </div>
    </div>
  </div>
);

window.UI = { Avatar, Verified, FormatText, ChartCard, PostCard };
