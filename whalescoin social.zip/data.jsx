// Whales Social — sample data
// Realistic crypto-whale flavored content

const PEOPLE = {
  vitalik: { id: "vitalik", name: "Vitalik B.", handle: "@vitalik.eth", whale: true, verified: true, color: "linear-gradient(135deg,#7B61FF,#3D2BFF)", initials: "VB" },
  cz: { id: "cz", name: "CZ", handle: "@cz_binance", whale: true, verified: true, color: "linear-gradient(135deg,#F5C249,#C99A1F)", initials: "CZ" },
  saylor: { id: "saylor", name: "Michael Saylor", handle: "@saylor", whale: true, verified: true, color: "linear-gradient(135deg,#F58F49,#C24D1F)", initials: "MS" },
  punk: { id: "punk", name: "Punk6529", handle: "@punk6529", whale: true, verified: true, color: "linear-gradient(135deg,#00E08A,#009B5C)", initials: "P6" },
  hayden: { id: "hayden", name: "Hayden Adams", handle: "@haydenzadams", whale: false, verified: true, color: "linear-gradient(135deg,#FF61D2,#B23A9A)", initials: "HA" },
  cobie: { id: "cobie", name: "Cobie", handle: "@cobie", whale: true, verified: true, color: "linear-gradient(135deg,#49B9F5,#1F76C9)", initials: "CB" },
  raoul: { id: "raoul", name: "Raoul Pal", handle: "@raoulgmi", whale: true, verified: true, color: "linear-gradient(135deg,#9DF549,#5FAA1F)", initials: "RP" },
  alameda: { id: "alameda", name: "OnchainSleuth", handle: "@onchain_alpha", whale: false, verified: false, color: "linear-gradient(135deg,#49F5DD,#1FC9B0)", initials: "OS" },
  loomdart: { id: "loomdart", name: "Loomdart", handle: "@loomdart", whale: false, verified: true, color: "linear-gradient(135deg,#F54979,#C91F4F)", initials: "LD" },
  me: { id: "me", name: "You", handle: "@whalewatcher", whale: false, verified: false, color: "linear-gradient(135deg,#00E08A,#009B5C)", initials: "WW" },
};

const Avatar = ({ p, size = 44, ring = false }) => {
  const style = {
    width: size, height: size,
    background: p.color,
    color: "#021A0F",
    fontSize: size * 0.36,
    fontWeight: 700,
    borderRadius: "50%",
    display: "grid", placeItems: "center",
    flexShrink: 0,
    fontFamily: "var(--font-display)",
    letterSpacing: "-0.02em",
    position: "relative",
  };
  return (
    <div className={"avatar-display" + (p.whale ? " whale" : "")} style={style}>
      {p.initials}
      {p.whale && (
        <span style={{
          position: "absolute", bottom: -1, right: -1,
          width: size * 0.32, height: size * 0.32,
          borderRadius: "50%",
          background: "linear-gradient(135deg,#FFD66E,#C99A1F)",
          border: `${size > 36 ? 2 : 1.5}px solid var(--bg)`,
          display: "grid", placeItems: "center",
          fontSize: size * 0.18,
        }}>
          <svg width={size * 0.18} height={size * 0.18} viewBox="0 0 24 24" fill="#3a2a07">
            <path d="M3 14c0-3 2.5-6 6.5-6 3 0 5 1.5 6 3 1-1 2.5-2 4-2 1 0 1.5.5 1.5.5s-.5 1-2 2c-.5.3-.5.7 0 1 1.5.7 2 2 2 3 0 0-1 1-2.5.5-1-.3-1.5-.7-2-1-1 1.5-3 2.5-6 2.5-2.5 0-4.5-.5-6-2-1 .5-2 .5-2.5 0 0-.5.5-1 1-1.5z" />
          </svg>
        </span>
      )}
    </div>
  );
};

const POSTS = [
  {
    id: "p1",
    person: PEOPLE.cobie,
    time: "12m",
    body: "people keep asking what i think about the next cycle. honestly? i think most of you will be too scared to buy the bottom and too greedy to sell the top. same as last time. same as next time.",
    media: null,
    trade: null,
    stats: { replies: 412, reposts: 1820, likes: 14200, views: 892000 },
  },
  {
    id: "p2",
    person: PEOPLE.alameda,
    time: "34m",
    body: "🚨 a wallet linked to a top-10 holder just moved 4,200 ETH ($14.6M) into a new cold wallet. no exchange interaction. quiet accumulation.",
    media: null,
    trade: { ticker: "ETH", price: "$3,471.20", change: "+2.4%", up: true },
    stats: { replies: 89, reposts: 612, likes: 3400, views: 240000 },
  },
  {
    id: "p3",
    person: PEOPLE.punk,
    time: "1h",
    body: "the most undervalued thing in this market is patience. the second is a friend who will tell you when you're being stupid. find both.",
    media: null,
    trade: null,
    stats: { replies: 156, reposts: 980, likes: 8100, views: 410000 },
  },
  {
    id: "p4",
    person: PEOPLE.vitalik,
    time: "2h",
    body: "thinking about how to make L2 → L1 withdrawals feel instant for users without sacrificing the security guarantees that make rollups rollups. there's a really nice design space between optimistic and zk that nobody's exploring properly.",
    media: { src: "diagram", caption: "L2 withdrawal flow" },
    trade: null,
    stats: { replies: 234, reposts: 1100, likes: 9800, views: 520000 },
  },
  {
    id: "p5",
    person: PEOPLE.saylor,
    time: "3h",
    body: "Bitcoin is digital property. Property is the foundation of civilization. The asset that becomes the global property layer wins the century.",
    media: null,
    trade: { ticker: "BTC", price: "$67,840", change: "+0.8%", up: true },
    stats: { replies: 1240, reposts: 4200, likes: 22000, views: 1800000 },
  },
  {
    id: "p6",
    person: PEOPLE.loomdart,
    time: "5h",
    body: "everyone's bullish at the top. everyone's bearish at the bottom. you can literally just do the opposite of what your timeline says and become rich.",
    media: null,
    trade: null,
    stats: { replies: 290, reposts: 2100, likes: 18000, views: 740000 },
  },
];

const FOLLOWING_POSTS = [
  {
    id: "fp1",
    person: PEOPLE.hayden,
    time: "8m",
    body: "v4 hooks are wild. you can now write a 30-line contract that deploys a market-making strategy with custom fees, oracles, and rebalancing logic. building DeFi feels like writing apps again.",
    stats: { replies: 67, reposts: 320, likes: 2400, views: 89000 },
  },
  {
    id: "fp2",
    person: PEOPLE.raoul,
    time: "1h",
    body: "the macro setup for risk assets in '26 is the cleanest I've seen in five years. liquidity expanding, central banks pivoting, debasement continuing. the only thing missing is a narrative — and those always show up late.",
    trade: { ticker: "M2", price: "$22.4T", change: "+4.1% YoY", up: true },
    stats: { replies: 180, reposts: 720, likes: 5800, views: 320000 },
  },
  {
    id: "fp3",
    person: PEOPLE.cz,
    time: "2h",
    body: "4. ignore the noise. focus on building. (a thread for builders 🧵)",
    stats: { replies: 412, reposts: 2200, likes: 14000, views: 980000 },
  },
];

const NOTIFICATIONS = [
  { id: "n1", type: "like", actors: [PEOPLE.cobie, PEOPLE.punk, PEOPLE.saylor], extraCount: 24, body: "liked your post: \"is the alt season finally back? on-chain volume says yes...\"", time: "8m" },
  { id: "n2", type: "follow", actors: [PEOPLE.vitalik], body: "followed you", time: "22m" },
  { id: "n3", type: "repost", actors: [PEOPLE.raoul, PEOPLE.cobie], extraCount: 12, body: "reposted your post about ETH staking yields", time: "1h" },
  { id: "n4", type: "tip", actors: [PEOPLE.punk], body: "sent you a tip of 0.05 ETH ≈ $173", time: "2h" },
  { id: "n5", type: "mention", actors: [PEOPLE.hayden], body: "mentioned you: \"@whalewatcher called this exact setup last month\"", time: "3h" },
  { id: "n6", type: "live", actors: [PEOPLE.saylor], body: "started a live broadcast: \"State of Bitcoin Q2\"", time: "5h" },
  { id: "n7", type: "follow", actors: [PEOPLE.loomdart, PEOPLE.alameda], body: "and 1 other followed you", time: "8h" },
  { id: "n8", type: "like", actors: [PEOPLE.hayden], extraCount: 0, body: "liked your reply", time: "1d" },
];

const CONVERSATIONS = [
  { id: "c1", person: PEOPLE.cobie, last: "lol fair, but the basis trade is still the cleanest play right now", time: "2m", unread: 2, online: true },
  { id: "c2", person: PEOPLE.punk, last: "you: sent the pitch deck", time: "18m", unread: 0, online: false, sentByMe: true },
  { id: "c3", person: PEOPLE.alameda, last: "🐋 new whale alert pinged your watchlist", time: "1h", unread: 1, online: true, isBot: true },
  { id: "c4", person: PEOPLE.hayden, last: "ship it. let's debug after if anything breaks.", time: "3h", unread: 0, online: true },
  { id: "c5", person: PEOPLE.raoul, last: "the everything code podcast drops tomorrow. preview attached.", time: "1d", unread: 0, online: false },
  { id: "c6", person: PEOPLE.loomdart, last: "you: 😂", time: "2d", unread: 0, online: false, sentByMe: true },
];

const TREND_TOPICS = [
  { cat: "Trending in Crypto", tag: "#Ethereum", posts: "284K posts", trend: "up" },
  { cat: "Whale Alerts", tag: "$ETH", posts: "92.4K posts", trend: "up", price: "$3,471", change: "+2.4%" },
  { cat: "Trending", tag: "#L2Summer", posts: "48.2K posts", trend: "up" },
  { cat: "Politics · Trending", tag: "Stablecoin Bill", posts: "112K posts", trend: "up" },
  { cat: "Whale Alerts", tag: "$BTC", posts: "1.2M posts", trend: "up", price: "$67,840", change: "+0.8%" },
  { cat: "Tech · Trending", tag: "#ZKProofs", posts: "21.8K posts", trend: "up" },
];

const SUGGESTED = [
  PEOPLE.hayden, PEOPLE.raoul, PEOPLE.loomdart,
];

Object.assign(window, { PEOPLE, POSTS, FOLLOWING_POSTS, NOTIFICATIONS, CONVERSATIONS, TREND_TOPICS, SUGGESTED, Avatar });
