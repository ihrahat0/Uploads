// Whales Social — Screens
const { useState: useS, useEffect: useE, useRef: useR } = React;

// ============ DRAWER ============
const Drawer = ({ open, onClose, onNavigate, theme, setTheme }) => {
  const items = [
    { id: 'profile', label: 'Profile', icon: 'home' },
    { id: 'bookmarks', label: 'Bookmarks', icon: 'bookmark' },
    { id: 'wallet', label: 'Wallet', icon: 'wallet' },
    { id: 'live', label: 'Go Live', icon: 'live' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
  ];
  return (
    <>
      <div className={`drawer-overlay ${open ? 'open' : ''}`} onClick={onClose} />
      <div className={`drawer ${open ? 'open' : ''}`}>
        <div style={{ padding: '60px 20px 20px' }}>
          <div className="row" style={{ gap: 12 }}>
            <Avatar user="you" size={56} />
            <button onClick={onClose} className="icon-btn" style={{ marginLeft: 'auto' }}><Icon name="close" size={20} /></button>
          </div>
          <div style={{ marginTop: 16, fontSize: 18, fontWeight: 700, letterSpacing: '-0.02em' }}>satoshi.eth</div>
          <div style={{ fontSize: 14, color: 'var(--text-3)' }}>@satoshi.eth</div>
          <div className="row" style={{ gap: 16, marginTop: 12, fontSize: 13 }}>
            <div><b style={{ color: 'var(--text)' }}>248</b> <span style={{ color: 'var(--text-3)' }}>Following</span></div>
            <div><b style={{ color: 'var(--text)' }}>12.4K</b> <span style={{ color: 'var(--text-3)' }}>Followers</span></div>
          </div>
          <div className="row" style={{ gap: 8, marginTop: 12, padding: '10px 12px', background: 'var(--bg-elev-2)', borderRadius: 'var(--r-md)', border: '1px solid var(--border)' }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'rgba(245, 197, 66, 0.15)', display: 'grid', placeItems: 'center', color: 'var(--whale-gold)' }}>
              <Icon name="whale" size={16} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--whale-gold)' }}>Whale Tier · Level 3</div>
              <div style={{ fontSize: 11, color: 'var(--text-3)' }}>$142.8K portfolio · top 4%</div>
            </div>
          </div>
        </div>
        <div className="divider" />
        <div style={{ padding: '8px 8px', flex: 1 }}>
          {items.map(it => (
            <button key={it.id} onClick={() => { onNavigate(it.id); onClose(); }}
              className="row" style={{ width: '100%', padding: '14px 16px', gap: 16, borderRadius: 12, fontSize: 16, fontWeight: 600 }}>
              <Icon name={it.icon} size={22} />
              {it.label}
            </button>
          ))}
        </div>
        <div className="divider" />
        <div style={{ padding: '12px 16px' }}>
          <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="row" style={{ gap: 10, fontSize: 14, color: 'var(--text-2)' }}>
            <Icon name="moon" size={18} /> {theme === 'dark' ? 'Light' : 'Dark'} mode
          </button>
        </div>
      </div>
    </>
  );
};

// ============ DISCOVER (HOME) ============
const ScreenDiscover = ({ activeTab, setActiveTab, onOpenPost }) => {
  const posts = activeTab === 'foryou' ? window.WhalesData.posts : window.WhalesData.followingPosts;
  return (
    <>
      <div className="segmented">
        <button className={`seg ${activeTab === 'foryou' ? 'active' : ''}`} onClick={() => setActiveTab('foryou')}>For You</button>
        <button className={`seg ${activeTab === 'following' ? 'active' : ''}`} onClick={() => setActiveTab('following')}>Following</button>
        <button className={`seg ${activeTab === 'whales' ? 'active' : ''}`} onClick={() => setActiveTab('whales')}>
          <span className="row" style={{ gap: 4 }}><Icon name="whale" size={14} stroke={1.8} /> Whales</span>
        </button>
      </div>
      <div className="body">
        {activeTab === 'whales' && (
          <div style={{ padding: '12px 16px', background: 'linear-gradient(180deg, rgba(245,197,66,0.06), transparent)', borderBottom: '1px solid var(--border)' }}>
            <div className="row" style={{ gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(245,197,66,0.15)', display: 'grid', placeItems: 'center', color: 'var(--whale-gold)' }}>
                <Icon name="whale" size={18} />
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--whale-gold)' }}>Whale Feed</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Posts from accounts with $1M+ on-chain</div>
              </div>
            </div>
          </div>
        )}
        {posts.map(p => <PostCard key={p.id} post={p} onOpen={onOpenPost} />)}
        <div style={{ height: 80 }} />
      </div>
    </>
  );
};

// ============ EXPLORE ============
const ScreenExplore = () => {
  const [q, setQ] = useS('');
  const trends = window.WhalesData.trends;
  const tabs = ['Trending', 'News', 'Markets', 'NFTs', 'DeFi'];
  const [tab, setTab] = useS('Trending');
  return (
    <>
      <div className="topbar">
        <div className="row" style={{ flex: 1, gap: 8, height: 38, padding: '0 14px', borderRadius: 'var(--r-pill)', background: 'var(--bg-elev-2)', border: '1px solid var(--border)' }}>
          <Icon name="search" size={18} style={{ color: 'var(--text-3)' }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search Whales" style={{ flex: 1, fontSize: 14 }} />
        </div>
        <button className="icon-btn"><Icon name="settings" size={20} /></button>
      </div>
      <div style={{ padding: '10px 12px 6px', overflowX: 'auto', whiteSpace: 'nowrap', borderBottom: '1px solid var(--border)' }} className="hide-scroll">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)} className="chip" style={{ marginRight: 6, ...(tab === t ? { background: 'var(--text)', color: 'var(--bg)', borderColor: 'var(--text)' } : {}) }}>{t}</button>
        ))}
      </div>
      <div className="body">
        <div style={{
          margin: '14px 16px',
          padding: '16px',
          borderRadius: 'var(--r-lg)',
          background: 'linear-gradient(135deg, rgba(0,214,143,0.12) 0%, rgba(245,197,66,0.06) 100%)',
          border: '1px solid rgba(0,214,143,0.2)',
          position: 'relative',
          overflow: 'hidden',
        }}>
          <div style={{ fontSize: 11, color: 'var(--whale-green)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1 }}>Featured · Live</div>
          <div style={{ fontSize: 20, fontWeight: 700, marginTop: 6, letterSpacing: '-0.02em', lineHeight: 1.2 }}>BTC reclaims $68K as smart money rotates back into majors</div>
          <div className="row" style={{ marginTop: 10, gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
            <div className="live-pulse" /> 2.4K watching · Coindesk Live
          </div>
        </div>
        <div style={{ padding: '8px 16px 4px', fontSize: 19, fontWeight: 700, letterSpacing: '-0.02em' }}>Trends for you</div>
        {trends.map((t, i) => (
          <button key={i} className="row" style={{
            width: '100%', padding: '12px 16px', gap: 12,
            justifyContent: 'space-between', borderBottom: '1px solid var(--border)',
            textAlign: 'left',
          }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="row" style={{ gap: 6, fontSize: 12, color: 'var(--text-3)' }}>
                {t.cat}
                {t.hot && <span style={{ color: 'var(--whale-red)' }}><Icon name="fire" size={12} /></span>}
              </div>
              <div className="row" style={{ gap: 6, marginTop: 2 }}>
                <span style={{ fontSize: 16, fontWeight: 700, color: t.tag.startsWith('$') ? 'var(--whale-gold)' : t.tag.startsWith('#') ? 'var(--whale-green)' : 'var(--text)' }}>{t.tag}</span>
                {t.dir && <span style={{ fontSize: 13, fontWeight: 600, color: t.dir === 'up' ? 'var(--whale-green)' : 'var(--whale-red)' }}>{t.change}</span>}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>{t.posts}</div>
            </div>
            {t.dir && <Sparkline dir={t.dir} width={70} height={28} />}
          </button>
        ))}
        <div style={{ height: 80 }} />
      </div>
    </>
  );
};

// ============ NOTIFICATIONS ============
const NotifIcon = ({ kind }) => {
  const map = {
    tip: { icon: 'tip', color: 'var(--whale-gold)', bg: 'rgba(245,197,66,0.15)' },
    follow: { icon: 'plus', color: 'var(--whale-green)', bg: 'rgba(0,214,143,0.15)' },
    like: { icon: 'heart-fill', color: 'var(--whale-red)', bg: 'rgba(255,77,109,0.15)' },
    repost: { icon: 'repost', color: 'var(--whale-green)', bg: 'rgba(0,214,143,0.15)' },
    reply: { icon: 'reply', color: 'var(--whale-blue)', bg: 'rgba(59,130,246,0.15)' },
    mention: { icon: 'reply', color: 'var(--whale-blue)', bg: 'rgba(59,130,246,0.15)' },
    whale: { icon: 'whale', color: 'var(--whale-gold)', bg: 'rgba(245,197,66,0.15)' },
    live: { icon: 'live', color: 'var(--whale-red)', bg: 'rgba(255,77,109,0.15)' },
  };
  const m = map[kind] || map.like;
  return (
    <div style={{ width: 36, height: 36, borderRadius: '50%', background: m.bg, color: m.color, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
      <Icon name={m.icon} size={18} />
    </div>
  );
};

const ScreenNotifications = () => {
  const [tab, setTab] = useS('all');
  const items = window.WhalesData.notifications;
  return (
    <>
      <div className="segmented">
        <button className={`seg ${tab === 'all' ? 'active' : ''}`} onClick={() => setTab('all')}>All</button>
        <button className={`seg ${tab === 'mentions' ? 'active' : ''}`} onClick={() => setTab('mentions')}>Mentions</button>
        <button className={`seg ${tab === 'tips' ? 'active' : ''}`} onClick={() => setTab('tips')}>
          <span className="row" style={{ gap: 4 }}><Icon name="tip" size={14} stroke={1.8} /> Tips</span>
        </button>
      </div>
      <div className="body">
        {items.map((n, i) => (
          <div key={i} className="row" style={{ padding: '14px 16px', gap: 12, borderBottom: '1px solid var(--border)', alignItems: 'flex-start' }}>
            <NotifIcon kind={n.kind} />
            <div style={{ flex: 1, minWidth: 0 }}>
              {n.kind === 'follow' ? (
                <>
                  <div className="row" style={{ gap: -8 }}>
                    {n.users.map((u, idx) => (
                      <div key={u} style={{ marginLeft: idx === 0 ? 0 : -10 }}>
                        <Avatar user={u} size={28} />
                      </div>
                    ))}
                  </div>
                  <div style={{ fontSize: 14, marginTop: 6, lineHeight: 1.4 }}>
                    <b>{window.WhalesData.users[n.users[0]].name}</b>, <b>{window.WhalesData.users[n.users[1]].name}</b> and <b>{n.extra} others</b> followed you
                  </div>
                </>
              ) : (
                <>
                  <Avatar user={n.user} size={28} />
                  <div style={{ fontSize: 14, marginTop: 6, lineHeight: 1.4 }}>
                    <b>{window.WhalesData.users[n.user]?.name}</b>
                    {n.kind === 'tip' && <> tipped you <span style={{ color: 'var(--whale-gold)', fontWeight: 700 }}>{n.amt} {n.sym}</span> <span style={{ color: 'var(--text-3)' }}>(${n.usd.toFixed(2)})</span> · {n.target}</>}
                    {n.kind === 'like' && <> and {fmt(n.count)} others liked {n.target}</>}
                    {n.kind === 'repost' && <> reposted {n.target}</>}
                    {n.kind === 'reply' && <>: "{n.target}"</>}
                    {n.kind === 'mention' && <> mentioned you: "{n.target}"</>}
                    {n.kind === 'whale' && <> {n.target}</>}
                    {n.kind === 'live' && <> {n.target}</>}
                  </div>
                </>
              )}
              <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 4 }}>{n.time}</div>
            </div>
            {n.kind === 'live' && (
              <button className="btn btn-green" style={{ padding: '6px 12px', fontSize: 12 }}>Join</button>
            )}
          </div>
        ))}
        <div style={{ height: 80 }} />
      </div>
    </>
  );
};

// ============ MESSAGES LIST ============
const ScreenMessages = ({ onOpenThread }) => {
  const dms = window.WhalesData.dms;
  return (
    <>
      <div className="topbar">
        <div className="row" style={{ flex: 1, gap: 8, height: 38, padding: '0 14px', borderRadius: 'var(--r-pill)', background: 'var(--bg-elev-2)', border: '1px solid var(--border)' }}>
          <Icon name="search" size={18} style={{ color: 'var(--text-3)' }} />
          <input placeholder="Search messages" style={{ flex: 1, fontSize: 14 }} />
        </div>
        <button className="icon-btn"><Icon name="settings" size={20} /></button>
      </div>
      <div className="body">
        <div style={{ padding: '12px 16px 8px' }}>
          <div style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 }}>Active now</div>
          <div className="row" style={{ gap: 14, overflowX: 'auto' }}>
            {['cobie', 'hsaka', 'deepfi', 'vitalik', 'pomp'].map(u => (
              <button key={u} className="col" style={{ alignItems: 'center', gap: 6, flexShrink: 0 }}>
                <div style={{ position: 'relative' }}>
                  <Avatar user={u} size={48} />
                  <div style={{ position: 'absolute', bottom: 0, right: 0, width: 12, height: 12, borderRadius: '50%', background: 'var(--whale-green)', boxShadow: '0 0 0 2px var(--bg)' }} />
                </div>
                <span style={{ fontSize: 11, color: 'var(--text-2)', maxWidth: 60, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{window.WhalesData.users[u].name.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="divider" />
        {dms.map(d => (
          <button key={d.id} onClick={() => onOpenThread(d)} className="row" style={{ width: '100%', padding: '12px 16px', gap: 12, borderBottom: '1px solid var(--border)', textAlign: 'left' }}>
            <div style={{ position: 'relative' }}>
              <Avatar user={d.user} size={48} showWhale />
              {d.online && <div style={{ position: 'absolute', bottom: 0, right: 0, width: 12, height: 12, borderRadius: '50%', background: 'var(--whale-green)', boxShadow: '0 0 0 2px var(--bg)' }} />}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <UserName user={d.user} compact />
                <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{d.time}</span>
              </div>
              <div className="row" style={{ justifyContent: 'space-between', marginTop: 2, gap: 8 }}>
                <span style={{ fontSize: 13, color: d.unread ? 'var(--text)' : 'var(--text-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: d.unread ? 600 : 400 }}>{d.last}</span>
                {d.unread > 0 && (
                  <span style={{ fontSize: 11, fontWeight: 700, padding: '2px 7px', borderRadius: 999, background: 'var(--whale-green)', color: '#00231A' }}>{d.unread}</span>
                )}
              </div>
            </div>
          </button>
        ))}
        <div style={{ height: 80 }} />
      </div>
      <button onClick={(e) => e.stopPropagation()} style={{
        position: 'absolute', right: 16, bottom: 96,
        width: 56, height: 56, borderRadius: '50%',
        background: 'var(--text)', color: 'var(--bg)',
        display: 'grid', placeItems: 'center',
        boxShadow: 'var(--shadow-md)',
        zIndex: 5,
      }}>
        <Icon name="edit" size={22} />
      </button>
    </>
  );
};

// ============ MESSAGE THREAD ============
const ScreenThread = ({ dm, onBack }) => {
  const [text, setText] = useS('');
  const [msgs, setMsgs] = useS(window.WhalesData.thread.messages);
  const send = () => {
    if (!text.trim()) return;
    setMsgs([...msgs, { from: 'me', text, time: 'now' }]);
    setText('');
  };
  const u = window.WhalesData.users[dm.user];
  return (
    <>
      <div className="topbar">
        <button className="icon-btn" onClick={onBack}><Icon name="arrow-left" size={22} /></button>
        <button className="row" style={{ flex: 1, gap: 10, paddingLeft: 4 }}>
          <Avatar user={dm.user} size={36} showWhale />
          <div style={{ textAlign: 'left' }}>
            <UserName user={dm.user} compact />
            <div style={{ fontSize: 11, color: dm.online ? 'var(--whale-green)' : 'var(--text-3)' }}>{dm.online ? 'Online now' : 'Last seen 2h ago'}</div>
          </div>
        </button>
        <button className="icon-btn"><Icon name="more" size={22} /></button>
      </div>
      <div className="body" style={{ padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ textAlign: 'center', fontSize: 11, color: 'var(--text-3)', margin: '8px 0 16px' }}>Today · 09:42</div>
        {msgs.map((m, i) => (
          <div key={i} className="row" style={{ justifyContent: m.from === 'me' ? 'flex-end' : 'flex-start' }}>
            {m.kind === 'tip' ? (
              <div style={{
                padding: '14px 16px',
                borderRadius: 'var(--r-lg)',
                background: 'linear-gradient(135deg, rgba(245,197,66,0.18) 0%, rgba(245,197,66,0.06) 100%)',
                border: '1px solid rgba(245,197,66,0.4)',
                maxWidth: '78%',
                color: 'var(--text)',
              }}>
                <div className="row" style={{ gap: 8 }}>
                  <Icon name="tip" size={20} style={{ color: 'var(--whale-gold)' }} />
                  <div>
                    <div style={{ fontSize: 11, color: 'var(--whale-gold)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1 }}>Tip received</div>
                    <div style={{ fontSize: 22, fontWeight: 700, marginTop: 2, fontVariantNumeric: 'tabular-nums' }}>{m.amount} {m.sym}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-3)' }}>≈ ${m.usd.toFixed(2)} USD</div>
                  </div>
                </div>
                <div style={{ fontSize: 13, marginTop: 8, color: 'var(--text-2)' }}>"{m.note}"</div>
              </div>
            ) : (
              <div style={{
                padding: '8px 14px',
                borderRadius: m.from === 'me' ? '20px 20px 6px 20px' : '20px 20px 20px 6px',
                background: m.from === 'me' ? 'linear-gradient(135deg, var(--whale-green) 0%, var(--whale-green-dim) 100%)' : 'var(--bg-elev-3)',
                color: m.from === 'me' ? '#00231A' : 'var(--text)',
                maxWidth: '78%',
                fontSize: 14,
                lineHeight: 1.4,
                fontWeight: m.from === 'me' ? 600 : 400,
              }}>
                {m.text}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="row" style={{ padding: '10px 12px 18px', gap: 8, borderTop: '1px solid var(--border)', background: 'var(--surface-glass)', backdropFilter: 'blur(20px)' }}>
        <button className="icon-btn"><Icon name="image" size={22} /></button>
        <button className="icon-btn"><Icon name="tip" size={22} style={{ color: 'var(--whale-gold)' }} /></button>
        <div className="row" style={{ flex: 1, padding: '8px 14px', borderRadius: 999, background: 'var(--bg-elev-3)', gap: 8 }}>
          <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Message" style={{ flex: 1, fontSize: 14 }} />
        </div>
        <button onClick={send} style={{ width: 38, height: 38, borderRadius: '50%', background: text.trim() ? 'var(--whale-green)' : 'var(--bg-elev-3)', color: text.trim() ? '#00231A' : 'var(--text-3)', display: 'grid', placeItems: 'center', transition: 'all 0.15s' }}><Icon name="send" size={18} /></button>
      </div>
    </>
  );
};

Object.assign(window, { Drawer, ScreenDiscover, ScreenExplore, ScreenNotifications, ScreenMessages, ScreenThread });
