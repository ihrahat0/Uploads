// Shared mock data for Whales Social
window.WhalesData = (function () {
  const users = {
    you: { handle: 'satoshi.eth', name: 'You', avatar: { hue: 142, seed: 'YO' }, whale: false, verified: false },
    vitalik: { handle: 'vitalik', name: 'Vitalik B.', avatar: { hue: 220, seed: 'VB' }, whale: true, verified: true, bio: 'building things' },
    cz: { handle: 'cz_binance', name: 'CZ', avatar: { hue: 45, seed: 'CZ' }, whale: true, verified: true },
    pomp: { handle: 'pompliano', name: 'Pomp', avatar: { hue: 28, seed: 'PO' }, whale: true, verified: true },
    cobie: { handle: 'cobie', name: 'Cobie', avatar: { hue: 280, seed: 'CO' }, whale: true, verified: true },
    hsaka: { handle: 'hsaka', name: 'Hsaka', avatar: { hue: 0, seed: 'HS' }, whale: false, verified: true },
    deepfi: { handle: 'deepfi.lens', name: 'Deep DeFi', avatar: { hue: 195, seed: 'DF' }, whale: false, verified: false },
    artgobblers: { handle: 'gobblers', name: 'Art Gobbler', avatar: { hue: 320, seed: 'AG' }, whale: false, verified: true },
    nansen: { handle: 'nansen_ai', name: 'Nansen', avatar: { hue: 230, seed: 'N' }, whale: false, verified: true },
    paradigm: { handle: 'paradigm', name: 'Paradigm', avatar: { hue: 260, seed: 'P' }, whale: false, verified: true },
    onchain: { handle: 'onchainwhale', name: 'On-Chain Whale', avatar: { hue: 165, seed: 'OW' }, whale: true, verified: false },
  };

  // Posts on the discover feed
  const posts = [
    {
      id: 'p1',
      user: 'cobie',
      time: '24m',
      text: "Reminder: most of crypto twitter has never been through a real bear market. The last one wasn't a bear, it was a vacation. Plan accordingly.",
      reposts: 1240, replies: 312, likes: 8923, views: '128K',
      tipped: 12.4,
      sentiment: 'bear',
    },
    {
      id: 'p2',
      user: 'vitalik',
      time: '1h',
      text: "Just published some thoughts on how zk-EVMs will change L2 economics over the next 18 months.",
      attachments: [{ kind: 'link', title: 'On the post-EIP-4844 rollup landscape', site: 'vitalik.eth.limo', img: { hue: 220 } }],
      reposts: 4302, replies: 891, likes: 24108, views: '892K',
      sentiment: 'neutral',
    },
    {
      id: 'p3',
      user: 'hsaka',
      time: '2h',
      text: "Watching $SOL bid into the close. Volume profile says we test 240 before we test 200. Will be wrong soon enough.",
      chart: { symbol: 'SOL/USD', price: '231.80', change: '+4.2%', dir: 'up' },
      reposts: 412, replies: 89, likes: 2310, views: '54K',
      sentiment: 'bull',
    },
    {
      id: 'p4',
      user: 'onchain',
      time: '3h',
      text: "🐋 Whale alert: 0x7f4...e2a moved 12,400 ETH ($31.2M) from cold storage to Coinbase. Fourth deposit this week from this wallet.",
      reposts: 2104, replies: 421, likes: 6712, views: '342K',
      sentiment: 'bear',
      pinned: true,
    },
    {
      id: 'p5',
      user: 'paradigm',
      time: '4h',
      text: "We're hiring. Looking for a research engineer to work on MEV, applied cryptography, and protocol design. Remote-first.",
      reposts: 612, replies: 142, likes: 3801, views: '98K',
    },
    {
      id: 'p6',
      user: 'pomp',
      time: '5h',
      text: "Bitcoin doesn't care about your election, your central bank, or your feelings. Block 879,420 is in. ⛏️",
      image: { hue: 28, label: 'BTC block' },
      reposts: 891, replies: 203, likes: 5102, views: '156K',
      sentiment: 'bull',
    },
    {
      id: 'p7',
      user: 'nansen',
      time: '7h',
      text: "Smart Money flows last 24h: → +$240M into stables, → -$92M out of memecoins, → +$112M into liquid restaking. Risk-off rotation continues.",
      reposts: 740, replies: 167, likes: 4203, views: '212K',
    },
  ];

  const followingPosts = [
    {
      id: 'f1',
      user: 'deepfi',
      time: '8m',
      text: "Hot take: 'Real Yield' was a 2022 narrative that just hasn't found its 2026 chart yet. Top 5 protocols by fees still haven't been touched.",
      reposts: 89, replies: 34, likes: 612, views: '12K',
    },
    {
      id: 'f2',
      user: 'artgobblers',
      time: '40m',
      text: "Drop tomorrow. 1,111 pieces. Allowlist closes at 18:00 UTC. Don't sleep on this one — last collection sold out in 6 minutes.",
      image: { hue: 320, label: 'Gobbler #441' },
      reposts: 412, replies: 198, likes: 2104, views: '58K',
    },
    {
      id: 'f3',
      user: 'cz',
      time: '2h',
      text: "4",
      reposts: 12410, replies: 3201, likes: 89212, views: '4.2M',
    },
  ];

  const trends = [
    { cat: 'Trending in Crypto', tag: '#ETH', posts: '142K posts', dir: 'up', change: '+4.2%' },
    { cat: 'Hot', tag: '#zkEVM', posts: '38.2K posts', hot: true },
    { cat: 'Trending', tag: '$SOL', posts: '92K posts', dir: 'up', change: '+8.1%' },
    { cat: 'Politics · Trending', tag: '#FedRateCut', posts: '210K posts' },
    { cat: 'Trending in DeFi', tag: '#LiquidRestaking', posts: '24K posts', dir: 'up', change: '+12%' },
    { cat: 'Trending', tag: '$DOGE', posts: '78K posts', dir: 'down', change: '-2.4%' },
  ];

  const notifications = [
    { kind: 'tip', user: 'cobie', amt: 0.05, sym: 'ETH', usd: 124.50, target: 'replied to your post', time: '2m' },
    { kind: 'follow', users: ['vitalik', 'paradigm'], extra: 14, time: '12m' },
    { kind: 'like', user: 'hsaka', target: "your post: \"Reminder: most of crypto twitter…\"", count: 320, time: '1h' },
    { kind: 'repost', user: 'pomp', target: 'your post about ETH/BTC ratio', time: '2h' },
    { kind: 'reply', user: 'deepfi', target: 'agreed, this is the best take I\'ve seen on it', time: '3h' },
    { kind: 'mention', user: 'nansen', target: 'cc @satoshi.eth — saw your dashboard, would love to chat', time: '5h' },
    { kind: 'whale', user: 'onchain', target: 'started following you', time: '8h' },
    { kind: 'live', user: 'cz', target: 'is live: "AMA — Q1 2026 review"', time: '1d' },
  ];

  const dms = [
    { id: 'd1', user: 'cobie', last: 'sent you a tip · 0.1 ETH', time: '2m', unread: 2, online: true },
    { id: 'd2', user: 'hsaka', last: 'check the order book on coinbase', time: '14m', unread: 1, online: true },
    { id: 'd3', user: 'paradigm', last: 'we should sync next week', time: '1h', unread: 0, online: false },
    { id: 'd4', user: 'deepfi', last: 'You: yeah lfg', time: '3h', unread: 0, online: true },
    { id: 'd5', user: 'nansen', last: 'GIF', time: '5h', unread: 0, online: false },
    { id: 'd6', user: 'pomp', last: 'You: 🫡', time: '1d', unread: 0, online: false },
    { id: 'd7', user: 'vitalik', last: 'thanks for the link', time: '2d', unread: 0, online: false },
  ];

  const thread = {
    user: 'cobie',
    online: true,
    messages: [
      { from: 'them', text: 'did you see the on-chain flows this morning', time: '09:42' },
      { from: 'them', text: 'whales are absolutely loading', time: '09:42' },
      { from: 'me', text: 'yeah saw the nansen dashboard. wild week.', time: '09:44' },
      { from: 'me', text: 'are you still long?', time: '09:44' },
      { from: 'them', text: 'spot, yes. derivatives, no.', time: '09:46' },
      { from: 'them', kind: 'tip', amount: 0.1, sym: 'ETH', usd: 248.5, note: 'for the alpha last week 🫡', time: '09:47' },
      { from: 'me', text: 'lol you didn\'t have to', time: '09:48' },
      { from: 'them', text: 'i did, your call on stETH was perfect timing', time: '09:48' },
    ],
  };

  const wallet = {
    total: 142857.42,
    change24: 4.82,
    holdings: [
      { sym: 'ETH', name: 'Ethereum', amt: 28.42, price: 4120.50, pct: 82, dir: 'up', change: '+4.2%' },
      { sym: 'BTC', name: 'Bitcoin', amt: 0.42, price: 68420.10, pct: 20, dir: 'up', change: '+1.8%' },
      { sym: 'SOL', name: 'Solana', amt: 142.0, price: 231.80, pct: 23, dir: 'up', change: '+8.1%' },
      { sym: 'USDC', name: 'USD Coin', amt: 4200.00, price: 1.00, pct: 3, dir: 'flat', change: '0.0%' },
      { sym: 'ARB', name: 'Arbitrum', amt: 1240.0, price: 1.92, pct: 2, dir: 'down', change: '-2.4%' },
    ],
    activity: [
      { kind: 'tip-in', from: 'cobie', amt: 0.1, sym: 'ETH', usd: 412.05, time: '2m' },
      { kind: 'send', to: 'paradigm', amt: 50, sym: 'USDC', usd: 50, time: '1h' },
      { kind: 'swap', from_sym: 'USDC', to_sym: 'ETH', amt: 1000, usd: 1000, time: '4h' },
      { kind: 'tip-out', to: 'hsaka', amt: 25, sym: 'USDC', usd: 25, time: '1d' },
    ],
  };

  return { users, posts, followingPosts, trends, notifications, dms, thread, wallet };
})();
