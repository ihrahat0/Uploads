// Whales Social — App root with routing, tweaks, toasts

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "accent": "#00E08A"
}/*EDITMODE-END*/;

const App = () => {
  const [tweaks, setTweaks] = useTweaks(TWEAK_DEFAULTS);
  const [route, setRoute] = React.useState("discover");
  const [routeArgs, setRouteArgs] = React.useState({});
  const [drawer, setDrawer] = React.useState(false);
  const [toasts, setToasts] = React.useState([]);
  const [lang, setLang] = React.useState("en");

  React.useEffect(() => {
    document.documentElement.dataset.theme = tweaks.theme;
  }, [tweaks.theme]);

  const go = (r, args = {}) => {
    setRoute(r);
    setRouteArgs(args);
    setDrawer(false);
    if (r === "go-live") {
      // also closes drawer
    }
  };

  const showToast = (text) => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, text }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2000);
  };

  const handleAction = (kind) => {
    const labels = {
      liked: "❤️ Liked",
      reposted: "🔄 Reposted",
      bookmarked: "🔖 Saved to Bookmarks",
    };
    if (labels[kind]) showToast(labels[kind]);
  };

  const isFullScreen = route === "go-live";
  const showBottomNav = !["go-live", "compose", "dm-thread"].includes(route);

  let screen;
  switch (route) {
    case "discover":
      screen = <DiscoverScreen go={go} openMenu={() => setDrawer(true)} openCompose={() => go("compose")} onAction={handleAction}/>;
      break;
    case "following":
      screen = <FollowingScreen go={go}/>;
      break;
    case "explore":
      screen = <ExploreScreen openMenu={() => setDrawer(true)} go={go}/>;
      break;
    case "notifications":
      screen = <NotificationsScreen openMenu={() => setDrawer(true)} go={go}/>;
      break;
    case "messages":
      screen = <MessagesScreen openMenu={() => setDrawer(true)} go={go}/>;
      break;
    case "dm-thread":
      screen = <DMThreadScreen go={go} conv={routeArgs.conv}/>;
      break;
    case "wallet":
      screen = <WalletScreen openMenu={() => setDrawer(true)} go={go}/>;
      break;
    case "go-live":
      screen = <GoLiveScreen go={go}/>;
      break;
    case "settings":
      screen = <SettingsScreen go={go} theme={tweaks.theme} setTheme={t => setTweaks({ theme: t })}/>;
      break;
    case "profile":
      screen = <ProfileScreen go={go} openMenu={() => setDrawer(true)}/>;
      break;
    case "bookmarks":
      screen = <BookmarksScreen go={go}/>;
      break;
    case "post-detail":
      screen = <PostDetailScreen go={go} post={routeArgs.post}/>;
      break;
    case "compose":
      screen = <ComposeScreen go={go} onPost={() => showToast("✓ Posted")}/>;
      break;
    default:
      screen = <DiscoverScreen go={go} openMenu={() => setDrawer(true)} openCompose={() => go("compose")} onAction={handleAction}/>;
  }

  return (
    <div className="stage">
      <div className="phone" data-screen-label={`whales-${route}`}>
        <div className="phone-inner">
          {!isFullScreen && <StatusBar/>}
          <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
            {screen}
          </div>
          {showBottomNav && (
            <BottomNav
              route={route}
              go={(r) => { if (r === "compose") go("compose"); else go(r); }}
              onCompose={() => go("compose")}
            />
          )}
        </div>
        <Drawer
          open={drawer}
          onClose={() => setDrawer(false)}
          go={go}
          theme={tweaks.theme}
          setTheme={(t) => setTweaks({ theme: t })}
          lang={lang}
          setLang={(l) => { setLang(l); showToast(`Language set to ${LANGUAGES.find(x => x.code === l)?.native || l}`); }}
        />
        <div className="toast-host">
          {toasts.map(t => (
            <div key={t.id} className="toast">
              <span className="dot"/>{t.text}
            </div>
          ))}
        </div>
      </div>
      <TweaksPanel>
        <TweakSection title="Theme">
          <TweakRadio
            value={tweaks.theme}
            onChange={(v) => setTweaks({ theme: v })}
            options={[{ value: "dark", label: "Dark" }, { value: "light", label: "Light" }]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
