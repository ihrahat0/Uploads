// Whales Social — shared shell

const StatusBar = () => (
  <div className="status-bar">
    <span>9:41</span>
    <span className="right">
      {/* signal */}
      <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor"><rect x="0" y="7" width="3" height="4" rx="1"/><rect x="5" y="5" width="3" height="6" rx="1"/><rect x="10" y="2" width="3" height="9" rx="1"/><rect x="15" y="0" width="2" height="11" rx="1" opacity=".4"/></svg>
      {/* wifi */}
      <svg width="16" height="11" viewBox="0 0 16 11" fill="currentColor"><path d="M8 11a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM3.5 6.5l1.4 1.4a4.4 4.4 0 0 1 6.2 0l1.4-1.4a6.4 6.4 0 0 0-9 0zM.7 3.7l1.4 1.4a8.4 8.4 0 0 1 11.8 0l1.4-1.4a10.4 10.4 0 0 0-14.6 0z"/></svg>
      {/* battery */}
      <svg width="26" height="12" viewBox="0 0 26 12" fill="none">
        <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke="currentColor" opacity=".5"/>
        <rect x="2" y="2" width="17" height="8" rx="1.5" fill="currentColor"/>
        <rect x="23.5" y="4" width="1.5" height="4" rx="0.7" fill="currentColor" opacity=".5"/>
      </svg>
    </span>
  </div>
);

const AppHeader = ({ onMenu, onSparkle, title = "Whales", showLogo = true, sparkleBadge = false }) => (
  <div className="app-header">
    <button className="avatar-btn" onClick={onMenu} aria-label="Open menu">
      <div style={{ width: "100%", height: "100%", borderRadius: "50%", background: "linear-gradient(135deg,#00E08A,#009B5C)", color: "#021A0F", display:"grid", placeItems:"center", fontWeight:700, fontSize:13 }}>WW</div>
    </button>
    {showLogo ? (
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ width: 28, height: 28, borderRadius: 8, display: "grid", placeItems: "center", background: "linear-gradient(135deg,#00E08A,#009B5C)", boxShadow: "0 4px 12px rgba(0,224,138,.4)" }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#021A0F"><path d="M3 14c0-3 2.5-6 6.5-6 3 0 5 1.5 6 3 1-1 2.5-2 4-2 1 0 1.5.5 1.5.5s-.5 1-2 2c-.5.3-.5.7 0 1 1.5.7 2 2 2 3 0 0-1 1-2.5.5-1-.3-1.5-.7-2-1-1 1.5-3 2.5-6 2.5-2.5 0-4.5-.5-6-2-1 .5-2 .5-2.5 0 0-.5.5-1 1-1.5z"/></svg>
        </span>
        <span className="header-title">{title}</span>
      </div>
    ) : (
      <span className="header-title">{title}</span>
    )}
    <button className="icon-btn" onClick={onSparkle} aria-label="Toggle feed">
      <IconSparkles size={22}/>
      {sparkleBadge && <span className="badge"/>}
    </button>
  </div>
);

const PageHeader = ({ onBack, title, sub, right }) => (
  <div className="page-header">
    <button className="icon-btn" onClick={onBack} aria-label="Back"><IconArrowLeft size={22}/></button>
    <div className="ph-titlewrap">
      <div className="ph-title">{title}</div>
      {sub && <div className="ph-sub">{sub}</div>}
    </div>
    {right && <div className="ph-actions">{right}</div>}
  </div>
);

const BottomNav = ({ route, go, onCompose }) => {
  const items = [
    { key: "discover", icon: IconHome },
    { key: "explore", icon: IconSearch },
    { key: "compose", icon: IconPlus, fab: true },
    { key: "notifications", icon: IconBell },
    { key: "messages", icon: IconMail },
  ];
  return (
    <nav className="bottom-nav" role="navigation">
      {items.map(it => {
        if (it.fab) {
          return (
            <button key="fab" className="bottom-nav-fab" onClick={onCompose} aria-label="Compose">
              <IconPlus size={26} sw={2.6}/>
            </button>
          );
        }
        const Active = it.icon;
        const active = route === it.key;
        return (
          <button key={it.key} className={"bottom-nav-item" + (active ? " active" : "")} onClick={() => go(it.key)} aria-label={it.key}>
            <Active size={26} sw={active ? 2.2 : 1.8}/>
          </button>
        );
      })}
    </nav>
  );
};

const LANGUAGES = [
  { code: "en", flag: "🇺🇸", label: "English", native: "English" },
  { code: "es", flag: "🇪🇸", label: "Spanish", native: "Español" },
  { code: "zh", flag: "🇨🇳", label: "Chinese", native: "中文" },
  { code: "ja", flag: "🇯🇵", label: "Japanese", native: "日本語" },
  { code: "ko", flag: "🇰🇷", label: "Korean", native: "한국어" },
  { code: "fr", flag: "🇫🇷", label: "French", native: "Français" },
  { code: "de", flag: "🇩🇪", label: "German", native: "Deutsch" },
  { code: "pt", flag: "🇧🇷", label: "Portuguese", native: "Português" },
  { code: "ru", flag: "🇷🇺", label: "Russian", native: "Русский" },
  { code: "ar", flag: "🇸🇦", label: "Arabic", native: "العربية" },
  { code: "hi", flag: "🇮🇳", label: "Hindi", native: "हिन्दी" },
  { code: "tr", flag: "🇹🇷", label: "Turkish", native: "Türkçe" },
];

const Drawer = ({ open, onClose, go, theme, setTheme, lang, setLang }) => {
  const [langOpen, setLangOpen] = React.useState(false);
  const currentLang = LANGUAGES.find(l => l.code === lang) || LANGUAGES[0];

  const items = [
    { key: "profile", label: "Profile", icon: IconUser },
    { key: "discover", label: "Discover", icon: IconHome },
    { key: "following", label: "Following", icon: IconUser, meta: "1,284" },
    { key: "explore", label: "Explore", icon: IconCompass },
    { key: "notifications", label: "Notifications", icon: IconBell, meta: "12" },
    { key: "messages", label: "Messages", icon: IconMail, meta: "3" },
    { key: "wallet", label: "Wallet", icon: IconWallet, meta: "$24.8K" },
    { key: "go-live", label: "Go Live", icon: IconLive, live: true },
    { key: "bookmarks", label: "Bookmarks", icon: IconBookmark },
  ];
  const account = [
    { key: "settings", label: "Settings & privacy", icon: IconSettings },
    { key: "verified", label: "Verified Whales", icon: IconStar },
    { key: "help", label: "Help Center", icon: IconHelp },
  ];

  return (
    <>
      <div className={"drawer-backdrop" + (open ? " open" : "")} onClick={onClose}/>
      <aside className={"drawer" + (open ? " open" : "")} aria-hidden={!open}>
        {/* Hero */}
        <div className="drawer-hero">
          <button className="drawer-close" onClick={onClose} aria-label="Close menu">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M6 6 18 18M18 6 6 18"/></svg>
          </button>
          <div className="drawer-avatar-wrap">
            <div className="drawer-avatar">WW</div>
            <div className="drawer-name-row">
              <div className="drawer-name">
                Whale Watcher
                <span className="verified" title="Verified">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14 4l2.5-.5.5 2.5 2.5.5-.5 2.5L21 11l-1.5 2 1.5 2-2 .5-.5 2.5-2.5-.5L14 20l-2-1.5L10 20l-2-2-2.5.5-.5-2.5L2.5 15 4 13l-1.5-2L4 9l.5-2.5L7 4l.5-2.5L10 4z M9.5 12.5l2 2 4-4.5"/></svg>
                </span>
              </div>
              <div className="drawer-handle">@whalewatcher</div>
            </div>
          </div>
          <span className="drawer-whale-badge">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M3 14c0-3 2.5-6 6.5-6 3 0 5 1.5 6 3 1-1 2.5-2 4-2 1 0 1.5.5 1.5.5s-.5 1-2 2c-.5.3-.5.7 0 1 1.5.7 2 2 2 3 0 0-1 1-2.5.5-1-.3-1.5-.7-2-1-1 1.5-3 2.5-6 2.5-2.5 0-4.5-.5-6-2-1 .5-2 .5-2.5 0 0-.5.5-1 1-1.5z"/></svg>
            WHALE TIER
          </span>
          <div className="drawer-stats">
            <button className="drawer-stat" onClick={() => go("following")}>
              <b>284</b><span>Following</span>
            </button>
            <button className="drawer-stat">
              <b>12.4K</b><span>Followers</span>
            </button>
            <button className="drawer-stat" onClick={() => go("wallet")}>
              <b style={{ color: "var(--whale-gold)" }}>2.84Ξ</b><span>Tipped</span>
            </button>
          </div>
        </div>

        {/* List */}
        <div className="drawer-list">
          {items.map(it => {
            const I = it.icon;
            return (
              <button key={it.key} className={"drawer-item" + (it.live ? " go-live" : "")} onClick={() => go(it.key)}>
                <I size={22} sw={1.8}/>
                <span>{it.label}</span>
                {it.live && (
                  <span style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 6, padding: "3px 8px", borderRadius: 999, background: "rgba(255,92,122,.12)", color: "#FF5C7A", fontSize: 10, fontWeight: 800, letterSpacing: ".06em" }}>
                    <span style={{ width: 6, height: 6, background: "#FF5C7A", borderRadius: "50%", boxShadow: "0 0 8px #FF5C7A", animation: "ring-out 1.6s ease-out infinite" }}/>
                    LIVE
                  </span>
                )}
                {it.meta && !it.live && <span className="item-meta">{it.meta}</span>}
              </button>
            );
          })}

          <div className="drawer-section-label">Preferences</div>

          {/* Language selector */}
          <div className={"drawer-lang" + (langOpen ? " open" : "")}>
            <button className="drawer-lang-trigger" onClick={() => setLangOpen(o => !o)}>
              <IconLanguage size={22} sw={1.8}/>
              <span className="flag">{currentLang.flag}</span>
              <span className="current">
                <b>Language</b>
                <span>{currentLang.native}</span>
              </span>
              <span className="chev">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 6 6 6-6 6"/></svg>
              </span>
            </button>
            <div className="drawer-lang-list">
              <div className="drawer-lang-list-inner">
                {LANGUAGES.map(l => (
                  <button
                    key={l.code}
                    className={"drawer-lang-item" + (l.code === lang ? " active" : "")}
                    onClick={() => { setLang(l.code); setLangOpen(false); }}
                  >
                    <span className="flag">{l.flag}</span>
                    <span className="label">{l.label}</span>
                    <span className="native">{l.native}</span>
                    {l.code === lang && (
                      <span className="check">
                        <IconCheckSm size={16} sw={2.4}/>
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Theme switch */}
          <div className="drawer-theme">
            <IconSparkles size={22} sw={1.8}/>
            <span>Appearance</span>
            <div
              className="drawer-theme-switch"
              data-theme={theme}
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              role="switch"
              aria-checked={theme === "light"}
            >
              <span>DARK</span>
              <span>LIGHT</span>
            </div>
          </div>

          <div className="drawer-section-label">Account</div>
          {account.map(it => {
            const I = it.icon;
            return (
              <button key={it.key} className="drawer-item" onClick={() => go(it.key === "settings" ? "settings" : "settings")}>
                <I size={22} sw={1.8}/>
                <span>{it.label}</span>
              </button>
            );
          })}
          <button className="drawer-item" style={{ color: "var(--like)" }}>
            <IconLogout size={22} sw={1.8} stroke="currentColor"/>
            <span>Log out</span>
          </button>
          <div style={{ height: 8 }}/>
        </div>

        <div className="drawer-foot">
          <span>Whales Social v1.0</span>
          <span className="net">Mainnet</span>
        </div>
      </aside>
    </>
  );
};

// ============ Sparkline (for trade chip) ============
const Sparkline = ({ up = true, data }) => {
  const points = data || [4, 6, 5, 7, 6, 8, 7, 9, 8, 11, 10, 13, 12, 14, 13, 16];
  const min = Math.min(...points), max = Math.max(...points);
  const w = 320, h = 56, pad = 6;
  const step = (w - pad*2) / (points.length - 1);
  const path = points.map((v, i) => {
    const x = pad + i * step;
    const y = pad + (1 - (v - min) / (max - min || 1)) * (h - pad*2);
    return `${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(" ");
  const fillPath = `${path} L ${w - pad} ${h - pad} L ${pad} ${h - pad} Z`;
  const color = up ? "var(--whale-green)" : "var(--like)";
  const colorAlpha = up ? "rgba(0,224,138,.18)" : "rgba(255,92,122,.18)";
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`sg-${up}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colorAlpha}/>
          <stop offset="100%" stopColor="transparent"/>
        </linearGradient>
      </defs>
      <path d={fillPath} fill={`url(#sg-${up})`}/>
      <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round"/>
    </svg>
  );
};

// ============ Post Card ============
const PostCard = ({ post, onOpen, onAction }) => {
  const [liked, setLiked] = React.useState(false);
  const [reposted, setReposted] = React.useState(false);
  const [bookmarked, setBookmarked] = React.useState(false);
  const [burst, setBurst] = React.useState(0);

  const fmtCount = (n) => n >= 1000000 ? (n/1000000).toFixed(1) + "M" : n >= 1000 ? (n/1000).toFixed(1) + "K" : n;

  const handleLike = (e) => {
    e.stopPropagation();
    if (!liked) { setBurst(b => b + 1); onAction && onAction("liked"); }
    setLiked(v => !v);
  };
  const handleRepost = (e) => {
    e.stopPropagation();
    if (!reposted) onAction && onAction("reposted");
    setReposted(v => !v);
  };
  const handleBookmark = (e) => {
    e.stopPropagation();
    if (!bookmarked) onAction && onAction("bookmarked");
    setBookmarked(v => !v);
  };

  const renderBody = (text) => {
    return text.split(/(\s+)/).map((tok, i) => {
      if (/^#\w+/.test(tok)) return <span key={i} className="tag">{tok}</span>;
      if (/^\$[A-Z]{2,5}/.test(tok)) return <span key={i} className="ticker">{tok}</span>;
      if (/^@[\w.]+/.test(tok)) return <span key={i} className="tag">{tok}</span>;
      return tok;
    });
  };

  return (
    <article className="post" onClick={() => onOpen && onOpen(post)}>
      <Avatar p={post.person} size={44}/>
      <div>
        <div className="post-head">
          <span className="post-name">
            {post.person.name}
            {post.person.verified && (
              <span className="post-verified" title="Verified">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 14 4l2.5-.5.5 2.5 2.5.5-.5 2.5L21 11l-1.5 2 1.5 2-2 .5-.5 2.5-2.5-.5L14 20l-2-1.5L10 20l-2-2-2.5.5-.5-2.5L2.5 15 4 13l-1.5-2L4 9l.5-2.5L7 4l.5-2.5L10 4z M9.5 12.5l2 2 4-4.5"/></svg>
              </span>
            )}
            {post.person.whale && (
              <span style={{ fontSize: 10, fontWeight: 800, color: "#3a2a07", background: "linear-gradient(135deg,#FFD66E,#C99A1F)", padding: "1px 6px", borderRadius: 4, letterSpacing: ".05em" }}>WHALE</span>
            )}
          </span>
          <span className="post-handle">{post.person.handle}</span>
          <span className="post-dot">·</span>
          <span className="post-time">{post.time}</span>
          <button className="post-more icon-btn" onClick={e => e.stopPropagation()} style={{ width: 28, height: 28 }}>
            <IconMore size={16}/>
          </button>
        </div>
        <div className="post-body">{renderBody(post.body)}</div>

        {post.media && (
          <div className="post-media">
            <div style={{ aspectRatio: "16/10", position: "relative", overflow: "hidden", background:
              "linear-gradient(135deg, #0E1218, #1B2230)"
            }}>
              <svg viewBox="0 0 320 200" style={{ width:"100%", height:"100%" }}>
                <defs>
                  <linearGradient id="gd1" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#00E08A" stopOpacity=".18"/>
                    <stop offset="100%" stopColor="#F5C249" stopOpacity=".10"/>
                  </linearGradient>
                </defs>
                <rect width="320" height="200" fill="url(#gd1)"/>
                {/* schematic L1/L2 nodes */}
                <g stroke="#00E08A" strokeWidth="1.5" fill="none" opacity=".9">
                  <circle cx="60" cy="100" r="22"/>
                  <circle cx="160" cy="60" r="14"/>
                  <circle cx="160" cy="140" r="14"/>
                  <circle cx="260" cy="100" r="22"/>
                  <path d="M82 100 L146 60"/>
                  <path d="M82 100 L146 140"/>
                  <path d="M174 60 L238 100"/>
                  <path d="M174 140 L238 100"/>
                </g>
                <text x="60" y="104" textAnchor="middle" fill="#fff" fontSize="9" fontFamily="monospace" fontWeight="700">L1</text>
                <text x="160" y="64" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="monospace">L2.A</text>
                <text x="160" y="144" textAnchor="middle" fill="#fff" fontSize="8" fontFamily="monospace">L2.B</text>
                <text x="260" y="104" textAnchor="middle" fill="#fff" fontSize="9" fontFamily="monospace" fontWeight="700">ZK</text>
                <text x="160" y="190" textAnchor="middle" fill="#B5BFCD" fontSize="9">withdrawal flow — sketch</text>
              </svg>
            </div>
          </div>
        )}

        {post.trade && (
          <div className="post-trade">
            <div className="post-trade-head">
              <div className="post-trade-tick">{post.trade.ticker}</div>
              <div className="post-trade-meta">
                <div className="t1">{post.trade.price}</div>
                <div className="t2">
                  <span className={post.trade.up ? "up" : "down"}>{post.trade.change}</span>
                  <span style={{ color: "var(--text-4)", margin: "0 6px" }}>·</span>
                  24h
                </div>
              </div>
              <button style={{ fontSize: 12, fontWeight: 700, padding: "8px 14px", borderRadius: 999, background: "var(--whale-green)", color: "#021A0F" }} onClick={e => e.stopPropagation()}>Trade</button>
            </div>
            <div className="post-trade-chart">
              <Sparkline up={post.trade.up}/>
            </div>
          </div>
        )}

        <div className="post-actions">
          <button className="post-action" onClick={e => e.stopPropagation()}>
            <IconReply size={18}/>
            <span>{fmtCount(post.stats.replies)}</span>
          </button>
          <button className={"post-action" + (reposted ? " reposted" : "")} onClick={handleRepost}>
            <IconRepost size={18}/>
            <span>{fmtCount(post.stats.reposts + (reposted ? 1 : 0))}</span>
          </button>
          <button className={"post-action" + (liked ? " liked" : "")} onClick={handleLike}>
            <span className="like-burst">
              <IconHeart size={18} filled={liked}/>
              {burst > 0 && <span key={burst} className="heart-burst" style={{ position: "absolute" }}/>}
            </span>
            <span>{fmtCount(post.stats.likes + (liked ? 1 : 0))}</span>
          </button>
          <button className="post-action">
            <IconViews size={18}/>
            <span>{fmtCount(post.stats.views)}</span>
          </button>
          <button className={"post-action" + (bookmarked ? " bookmarked" : "")} onClick={handleBookmark}>
            <IconBookmark size={18}/>
          </button>
          <button className="post-action" onClick={e => e.stopPropagation()}>
            <IconShare size={18}/>
          </button>
        </div>
      </div>
    </article>
  );
};

Object.assign(window, { StatusBar, AppHeader, PageHeader, BottomNav, Drawer, Sparkline, PostCard });
